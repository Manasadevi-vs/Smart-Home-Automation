import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name"),
  role: text("role").default("user"),
  // Gamification fields
  points: integer("points").default(0),
  level: integer("level").default(1),
  streak: integer("streak").default(0),
  lastActive: timestamp("last_active").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  role: true,
});

// Rooms table
export const rooms = pgTable("rooms", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  icon: text("icon").default("home"),
});

export const insertRoomSchema = createInsertSchema(rooms).pick({
  name: true,
  icon: true,
});

// Device Types
export const deviceTypes = {
  light: "light",
  fan: "fan",
} as const;

// Devices table
export const devices = pgTable("devices", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // "light" or "fan"
  roomId: integer("room_id").notNull(),
  topic: text("topic").notNull(), // MQTT topic for device control
  status: boolean("status").default(false),
  brightness: integer("brightness").default(0), // For lights
  color: text("color").default("warm"), // For lights
  speed: integer("speed").default(0), // For fans
  mode: text("mode").default("normal"), // For fans
  // Gamification fields
  usageCount: integer("usage_count").default(0),
  energySaved: integer("energy_saved").default(0), // in watt-hours
  efficiencyRating: integer("efficiency_rating").default(50),
});

export const insertDeviceSchema = createInsertSchema(devices).pick({
  name: true,
  type: true,
  roomId: true,
  topic: true,
  status: true,
  brightness: true,
  color: true,
  speed: true,
  mode: true,
});

// Automation rules
export const rules = pgTable("rules", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  isActive: boolean("is_active").default(true),
  trigger: text("trigger").notNull(), // "time", "device", "sensor"
  triggerData: jsonb("trigger_data"), // JSON data for trigger conditions
  actions: jsonb("actions").notNull(), // JSON array of device actions
  // Gamification fields
  triggerCount: integer("trigger_count").default(0),
  energySaved: integer("energy_saved").default(0), // estimated energy saved by this rule
});

export const insertRuleSchema = createInsertSchema(rules).pick({
  name: true,
  description: true,
  isActive: true,
  trigger: true,
  triggerData: true,
  actions: true,
});

// Energy usage data
export const energyUsage = pgTable("energy_usage", {
  id: serial("id").primaryKey(),
  deviceId: integer("device_id").notNull(),
  timestamp: timestamp("timestamp").notNull(),
  value: integer("value").notNull(), // in watt-hours
});

export const insertEnergyUsageSchema = createInsertSchema(energyUsage).pick({
  deviceId: true,
  timestamp: true,
  value: true,
});

// User preferences
export const preferences = pgTable("preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  lightBrightness: integer("light_brightness").default(65),
  lightColorMorning: text("light_color_morning").default("cool"),
  lightColorDay: text("light_color_day").default("neutral"),
  lightColorEvening: text("light_color_evening").default("warm"),
  autoAdjustLight: boolean("auto_adjust_light").default(true),
  fanSpeed: integer("fan_speed").default(50),
  minTemperature: integer("min_temperature").default(22),
  maxTemperature: integer("max_temperature").default(26),
  autoAdjustFan: boolean("auto_adjust_fan").default(true),
});

export const insertPreferenceSchema = createInsertSchema(preferences).pick({
  userId: true,
  lightBrightness: true,
  lightColorMorning: true,
  lightColorDay: true,
  lightColorEvening: true,
  autoAdjustLight: true,
  fanSpeed: true,
  minTemperature: true,
  maxTemperature: true,
  autoAdjustFan: true,
});

// Achievement types
export const achievementTypes = {
  energy_saver: "energy_saver", 
  automation_master: "automation_master",
  device_manager: "device_manager",
  smart_lighter: "smart_lighter",
  climate_controller: "climate_controller",
  daily_streak: "daily_streak",
} as const;

// Achievements table
export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(), // from achievementTypes
  icon: text("icon").notNull(),
  pointsAwarded: integer("points_awarded").default(10),
  requirement: integer("requirement").notNull(), // value needed to complete the achievement
  tier: integer("tier").default(1), // 1 = bronze, 2 = silver, 3 = gold
});

export const insertAchievementSchema = createInsertSchema(achievements).pick({
  name: true,
  description: true,
  type: true,
  icon: true,
  pointsAwarded: true,
  requirement: true,
  tier: true,
});

// User achievements progress
export const userAchievements = pgTable("user_achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  achievementId: integer("achievement_id").notNull(),
  progress: integer("progress").default(0),
  completed: boolean("completed").default(false),
  completedAt: timestamp("completed_at"),
});

export const insertUserAchievementSchema = createInsertSchema(userAchievements).pick({
  userId: true,
  achievementId: true,
  progress: true,
  completed: true,
});

// Challenge types
export const challengeTypes = {
  daily: "daily",
  weekly: "weekly",
  monthly: "monthly",
  special: "special",
} as const;

// Challenges table
export const challenges = pgTable("challenges", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(), // from challengeTypes
  pointsAwarded: integer("points_awarded").default(20),
  requirement: integer("requirement").notNull(), // value needed to complete the challenge
  icon: text("icon").notNull(),
  startDate: timestamp("start_date").defaultNow(),
  endDate: timestamp("end_date"),
  active: boolean("active").default(true),
});

export const insertChallengeSchema = createInsertSchema(challenges).pick({
  name: true,
  description: true,
  type: true,
  pointsAwarded: true,
  requirement: true,
  icon: true,
  startDate: true,
  endDate: true,
  active: true,
});

// User challenges progress
export const userChallenges = pgTable("user_challenges", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  challengeId: integer("challenge_id").notNull(),
  progress: integer("progress").default(0),
  completed: boolean("completed").default(false),
  completedAt: timestamp("completed_at"),
});

export const insertUserChallengeSchema = createInsertSchema(userChallenges).pick({
  userId: true,
  challengeId: true,
  progress: true,
  completed: true,
});

// Types definitions
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertRoom = z.infer<typeof insertRoomSchema>;
export type Room = typeof rooms.$inferSelect;

export type InsertDevice = z.infer<typeof insertDeviceSchema>;
export type Device = typeof devices.$inferSelect;

export type InsertRule = z.infer<typeof insertRuleSchema>;
export type Rule = typeof rules.$inferSelect;

export type InsertEnergyUsage = z.infer<typeof insertEnergyUsageSchema>;
export type EnergyUsage = typeof energyUsage.$inferSelect;

export type InsertPreference = z.infer<typeof insertPreferenceSchema>;
export type Preference = typeof preferences.$inferSelect;

export type InsertAchievement = z.infer<typeof insertAchievementSchema>;
export type Achievement = typeof achievements.$inferSelect;

export type InsertUserAchievement = z.infer<typeof insertUserAchievementSchema>;
export type UserAchievement = typeof userAchievements.$inferSelect;

export type InsertChallenge = z.infer<typeof insertChallengeSchema>;
export type Challenge = typeof challenges.$inferSelect;

export type InsertUserChallenge = z.infer<typeof insertUserChallengeSchema>;
export type UserChallenge = typeof userChallenges.$inferSelect;
