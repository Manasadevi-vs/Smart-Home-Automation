import React, { createContext, useContext, useState, useEffect } from "react";
import { 
  Device, User, Room, Rule, Preference, 
  InsertDevice, InsertRule, InsertRoom, InsertUser
} from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useWebSocketConnection, controlDevice } from "@/lib/mqtt";
import { calculateComfortScore, calculateEnergyUsage } from "@/lib/deviceUtils";
import { useToast } from "@/hooks/use-toast";

interface SmartHomeContextType {
  // Data
  user: User | null;
  devices: Device[];
  rooms: Room[];
  rules: Rule[];
  preferences: Preference | null;
  
  // WebSocket and MQTT state
  wsConnected: boolean;
  mqttConnected: boolean;
  lastUpdate: Date | null;
  
  // Environment data
  temperature: number;
  humidity: number;
  
  // Calculated values
  activeDevices: Device[];
  energyUsage: number;
  comfortScore: {
    score: number;
    tempScore: number;
    lightScore: number;
  };
  
  // CRUD operations
  createDevice: (device: InsertDevice) => Promise<Device | null>;
  updateDevice: (id: number, updates: Partial<Device>) => Promise<Device | null>;
  getDeviceById: (id: number) => Device | undefined;
  getDevicesByRoom: (roomId: number) => Device[];
  
  createRoom: (room: InsertRoom) => Promise<Room | null>;
  getRoomById: (id: number) => Room | undefined;
  
  createRule: (rule: InsertRule) => Promise<Rule | null>;
  updateRule: (id: number, updates: Partial<Rule>) => Promise<Rule | null>;
  getRuleById: (id: number) => Rule | undefined;
  
  updatePreferences: (userId: number, updates: Partial<Preference>) => Promise<Preference | null>;
}

const SmartHomeContext = createContext<SmartHomeContextType | undefined>(undefined);

export function SmartHomeProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [devices, setDevices] = useState<Device[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [rules, setRules] = useState<Rule[]>([]);
  const [preferences, setPreferences] = useState<Preference | null>(null);
  
  // Environment state
  const [temperature, setTemperature] = useState(24);
  const [humidity, setHumidity] = useState(72);
  
  const { connected: wsConnected, mqttConnected, lastUpdate, sendMessage } = useWebSocketConnection();
  const { toast } = useToast();
  
  // Load initial data
  useEffect(() => {
    const loadData = async () => {
      try {
        // Load users, just get the first one for demo
        const usersResponse = await apiRequest('GET', '/api/users');
        const users = await usersResponse.json();
        if (users.length > 0) {
          setUser(users[0]);
          
          // Load preferences for this user
          try {
            const preferencesResponse = await apiRequest('GET', `/api/preferences/${users[0].id}`);
            const preferencesData = await preferencesResponse.json();
            setPreferences(preferencesData);
          } catch (error) {
            console.error('Error loading preferences:', error);
          }
        }
        
        // Load rooms
        const roomsResponse = await apiRequest('GET', '/api/rooms');
        const roomsData = await roomsResponse.json();
        setRooms(roomsData);
        
        // Load devices
        const devicesResponse = await apiRequest('GET', '/api/devices');
        const devicesData = await devicesResponse.json();
        setDevices(devicesData);
        
        // Load rules
        const rulesResponse = await apiRequest('GET', '/api/rules');
        const rulesData = await rulesResponse.json();
        setRules(rulesData);
      } catch (error) {
        console.error('Error loading initial data:', error);
        toast({
          title: "Error",
          description: "Failed to load data. Please try again.",
          variant: "destructive",
        });
      }
    };
    
    loadData();
  }, [toast]);
  
  // Computed values
  const activeDevices = devices.filter(device => device.status);
  const energyUsage = calculateEnergyUsage(devices);
  const comfortScore = calculateComfortScore(devices, temperature, humidity);
  
  // Device operations
  const getDeviceById = (id: number) => devices.find(device => device.id === id);
  
  const getDevicesByRoom = (roomId: number) => 
    devices.filter(device => device.roomId === roomId);
  
  const createDevice = async (device: InsertDevice): Promise<Device | null> => {
    try {
      const response = await apiRequest('POST', '/api/devices', device);
      const newDevice = await response.json();
      setDevices(prevDevices => [...prevDevices, newDevice]);
      return newDevice;
    } catch (error) {
      console.error('Error creating device:', error);
      toast({
        title: "Error",
        description: "Failed to create device. Please try again.",
        variant: "destructive",
      });
      return null;
    }
  };
  
  const updateDevice = async (id: number, updates: Partial<Device>): Promise<Device | null> => {
    try {
      const response = await apiRequest('PUT', `/api/devices/${id}`, updates);
      const updatedDevice = await response.json();
      
      setDevices(prevDevices => 
        prevDevices.map(device => 
          device.id === id ? { ...device, ...updatedDevice } : device
        )
      );
      
      // Also send via WebSocket if available
      if (wsConnected) {
        const device = getDeviceById(id);
        if (device) {
          controlDevice(
            sendMessage, 
            device.topic, 
            { ...device, ...updates }
          );
        }
      }
      
      return updatedDevice;
    } catch (error) {
      console.error('Error updating device:', error);
      toast({
        title: "Error",
        description: "Failed to update device. Please try again.",
        variant: "destructive",
      });
      return null;
    }
  };
  
  // Room operations
  const getRoomById = (id: number) => rooms.find(room => room.id === id);
  
  const createRoom = async (room: InsertRoom): Promise<Room | null> => {
    try {
      const response = await apiRequest('POST', '/api/rooms', room);
      const newRoom = await response.json();
      setRooms(prevRooms => [...prevRooms, newRoom]);
      return newRoom;
    } catch (error) {
      console.error('Error creating room:', error);
      toast({
        title: "Error",
        description: "Failed to create room. Please try again.",
        variant: "destructive",
      });
      return null;
    }
  };
  
  // Rule operations
  const getRuleById = (id: number) => rules.find(rule => rule.id === id);
  
  const createRule = async (rule: InsertRule): Promise<Rule | null> => {
    try {
      const response = await apiRequest('POST', '/api/rules', rule);
      const newRule = await response.json();
      setRules(prevRules => [...prevRules, newRule]);
      return newRule;
    } catch (error) {
      console.error('Error creating rule:', error);
      toast({
        title: "Error",
        description: "Failed to create automation rule. Please try again.",
        variant: "destructive",
      });
      return null;
    }
  };
  
  const updateRule = async (id: number, updates: Partial<Rule>): Promise<Rule | null> => {
    try {
      const response = await apiRequest('PUT', `/api/rules/${id}`, updates);
      const updatedRule = await response.json();
      
      setRules(prevRules => 
        prevRules.map(rule => 
          rule.id === id ? { ...rule, ...updatedRule } : rule
        )
      );
      
      return updatedRule;
    } catch (error) {
      console.error('Error updating rule:', error);
      toast({
        title: "Error",
        description: "Failed to update automation rule. Please try again.",
        variant: "destructive",
      });
      return null;
    }
  };
  
  // Preference operations
  const updatePreferences = async (
    userId: number, 
    updates: Partial<Preference>
  ): Promise<Preference | null> => {
    try {
      const response = await apiRequest('PUT', `/api/preferences/${userId}`, updates);
      const updatedPreferences = await response.json();
      
      setPreferences(updatedPreferences);
      
      return updatedPreferences;
    } catch (error) {
      console.error('Error updating preferences:', error);
      toast({
        title: "Error",
        description: "Failed to update user preferences. Please try again.",
        variant: "destructive",
      });
      return null;
    }
  };
  
  const value = {
    // Data
    user,
    devices,
    rooms,
    rules,
    preferences,
    
    // WebSocket and MQTT state
    wsConnected,
    mqttConnected,
    lastUpdate,
    
    // Environment data
    temperature,
    humidity,
    
    // Calculated values
    activeDevices,
    energyUsage,
    comfortScore,
    
    // CRUD operations
    createDevice,
    updateDevice,
    getDeviceById,
    getDevicesByRoom,
    
    createRoom,
    getRoomById,
    
    createRule,
    updateRule,
    getRuleById,
    
    updatePreferences,
  };
  
  return (
    <SmartHomeContext.Provider value={value}>
      {children}
    </SmartHomeContext.Provider>
  );
}

export const useSmartHome = () => {
  const context = useContext(SmartHomeContext);
  if (context === undefined) {
    throw new Error('useSmartHome must be used within a SmartHomeProvider');
  }
  return context;
};
