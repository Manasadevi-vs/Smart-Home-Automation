import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import Lighting from "@/pages/Lighting";
import Fans from "@/pages/Fans";
import EnergyUsage from "@/pages/EnergyUsage";
import Scheduling from "@/pages/Scheduling";
import UserPreferences from "@/pages/UserPreferences";
import Gamification from "@/pages/Gamification";
import Sidebar from "@/components/layout/Sidebar";
import MobileNavBar from "@/components/layout/MobileNavBar";
import { useIsMobile as useMobile } from "@/hooks/use-mobile";
import { Component, ErrorInfo, ReactNode } from "react";

// Error boundary to catch errors
interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends Component<{ children: ReactNode, fallback?: ReactNode }, ErrorBoundaryState> {
  state: ErrorBoundaryState = { hasError: false, error: null };
  
  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }
  
  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Error caught by ErrorBoundary:", error, errorInfo);
  }
  
  render() {
    if (this.state.hasError) {
      return this.props.fallback || (
        <div className="p-4 m-4 bg-red-100 border border-red-400 text-red-700 rounded">
          <h2 className="text-lg font-bold mb-2">Something went wrong</h2>
          <details>
            <summary>Error details</summary>
            <pre className="mt-2 p-2 bg-red-50 text-sm overflow-auto">
              {this.state.error?.message || 'Unknown error'}
            </pre>
          </details>
        </div>
      );
    }
    
    return this.props.children;
  }
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/lighting" component={Lighting} />
      <Route path="/fans" component={Fans} />
      <Route path="/energy" component={EnergyUsage} />
      <Route path="/scheduling" component={Scheduling} />
      <Route path="/preferences" component={UserPreferences} />
      <Route path="/gamification" component={Gamification} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const isMobile = useMobile();

  return (
    <>
      <div className="flex h-screen w-full bg-background text-foreground">
        <ErrorBoundary>
          <div className="hidden md:block">
            <Sidebar />
          </div>
        </ErrorBoundary>
        
        {isMobile && (
          <ErrorBoundary>
            <MobileNavBar />
          </ErrorBoundary>
        )}
        
        <main className="flex-1 overflow-y-auto md:pt-0 pt-14">
          <ErrorBoundary>
            <Router />
          </ErrorBoundary>
        </main>
      </div>
      <Toaster />
    </>
  );
}

export default App;
