import { useState, useEffect } from "react";
import { EnergyChart } from "@/components/dashboard/EnergyChart";
import { Device } from "@shared/schema";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { apiRequest } from "@/lib/queryClient";

type EnergyDataPoint = {
  time: string;
  value: number;
};

type EnergyBreakdown = {
  name: string;
  value: number;
  color: string;
  percentage: number;
};

export default function EnergyUsage() {
  const [devices, setDevices] = useState<Device[]>([]);
  const [activeDevices, setActiveDevices] = useState<Device[]>([]);
  const [period, setPeriod] = useState<"day" | "week" | "month">("day");
  const [energyData, setEnergyData] = useState<EnergyDataPoint[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");

  // Calculate total energy usage 
  const totalDailyUsage = energyData.reduce((sum, item) => sum + item.value, 0);
  const estimatedMonthlyCost = totalDailyUsage * 0.15 * 30; // Assuming $0.15 per kWh

  // Mock device breakdown data (in a real app, this would come from the API)
  const deviceBreakdown: EnergyBreakdown[] = [
    { name: "Lighting", value: totalDailyUsage * 0.33, color: "hsl(var(--primary))", percentage: 33 },
    { name: "Fans", value: totalDailyUsage * 0.5, color: "hsl(var(--chart-2))", percentage: 50 },
    { name: "Other Devices", value: totalDailyUsage * 0.17, color: "hsl(var(--chart-3))", percentage: 17 },
  ];

  // Mock room breakdown data
  const roomBreakdown: EnergyBreakdown[] = [
    { name: "Living Room", value: totalDailyUsage * 0.45, color: "hsl(var(--chart-1))", percentage: 45 },
    { name: "Bedroom", value: totalDailyUsage * 0.25, color: "hsl(var(--chart-2))", percentage: 25 },
    { name: "Kitchen", value: totalDailyUsage * 0.20, color: "hsl(var(--chart-3))", percentage: 20 },
    { name: "Others", value: totalDailyUsage * 0.10, color: "hsl(var(--chart-4))", percentage: 10 },
  ];

  // Fetch devices
  useEffect(() => {
    const fetchDevices = async () => {
      try {
        const response = await fetch('/api/devices');
        const data = await response.json();
        setDevices(data);
        setActiveDevices(data.filter((device: Device) => device.status));
      } catch (error) {
        console.error('Error fetching devices:', error);
      }
    };
    
    fetchDevices();
  }, []);

  // Fetch energy data
  useEffect(() => {
    const fetchEnergyData = async () => {
      setIsLoading(true);
      try {
        const response = await apiRequest("GET", `/api/energy-usage?period=${period}`);
        const data = await response.json();
        
        // Transform data for chart
        let formattedData: EnergyDataPoint[] = [];
        
        if (period === "day") {
          // For day view, show hourly data
          formattedData = Array.from({ length: 24 }, (_, i) => {
            const hour = i;
            return {
              time: `${hour}:00`,
              value: Math.random() * 2 + 0.5, // Replace with actual data
            };
          });
        } else if (period === "week") {
          // For week view, show daily data
          const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
          formattedData = days.map(day => ({
            time: day,
            value: Math.random() * 15 + 5, // Replace with actual data
          }));
        } else {
          // For month view, show weekly data
          formattedData = Array.from({ length: 4 }, (_, i) => ({
            time: `Week ${i + 1}`,
            value: Math.random() * 60 + 20, // Replace with actual data
          }));
        }
        
        setEnergyData(formattedData);
      } catch (error) {
        console.error("Failed to fetch energy data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchEnergyData();
  }, [period]);

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto">
      {/* Header section */}
      <div className="mb-6">
        <h1 className="text-2xl md:text-3xl font-bold">Energy Usage</h1>
        <p className="text-muted-foreground mt-1">
          Monitor and analyze your smart home energy consumption.
        </p>
      </div>
      
      {/* Energy Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col gap-1">
              <span className="text-muted-foreground text-sm">Today's Usage</span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-bold">{totalDailyUsage.toFixed(1)} kWh</span>
                <span className="text-green-500 text-xs">-12%</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col gap-1">
              <span className="text-muted-foreground text-sm">Active Devices</span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-bold">{activeDevices.length}</span>
                <span className="text-muted-foreground text-xs">of {devices.length} total</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col gap-1">
              <span className="text-muted-foreground text-sm">Est. Monthly Cost</span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-bold">${estimatedMonthlyCost.toFixed(2)}</span>
                <span className="text-green-500 text-xs">-8%</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col gap-1">
              <span className="text-muted-foreground text-sm">Carbon Footprint</span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-bold">{(totalDailyUsage * 0.85).toFixed(1)} kg</span>
                <span className="text-green-500 text-xs">CO₂e/day</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Tabs for different views */}
      <Tabs 
        defaultValue="overview" 
        value={activeTab}
        onValueChange={setActiveTab}
        className="mb-6"
      >
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="devices">By Device</TabsTrigger>
          <TabsTrigger value="rooms">By Room</TabsTrigger>
          <TabsTrigger value="history">Usage History</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="mt-4">
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Energy Consumption Overview</CardTitle>
              <CardDescription>
                View your home's energy usage patterns and identify opportunities to save energy
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-0">
              <EnergyChart 
                data={energyData}
                deviceBreakdown={deviceBreakdown}
                period={period}
                onPeriodChange={setPeriod}
              />
            </CardContent>
          </Card>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Energy-saving Tips</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  <li className="flex gap-2">
                    <i className="ri-lightbulb-line text-accent mt-0.5"></i>
                    <div>
                      <p className="font-medium">Optimize lighting schedules</p>
                      <p className="text-sm text-muted-foreground">Your lights are on for 14+ hours daily. Consider reducing this by 20%.</p>
                    </div>
                  </li>
                  <li className="flex gap-2">
                    <i className="ri-windy-line text-primary mt-0.5"></i>
                    <div>
                      <p className="font-medium">Reduce fan speed when not at home</p>
                      <p className="text-sm text-muted-foreground">Running fans at lower speeds can reduce energy consumption by up to 40%.</p>
                    </div>
                  </li>
                  <li className="flex gap-2">
                    <i className="ri-timer-line text-secondary mt-0.5"></i>
                    <div>
                      <p className="font-medium">Set up automated schedules</p>
                      <p className="text-sm text-muted-foreground">Automate your devices to turn off when you're away or sleeping.</p>
                    </div>
                  </li>
                </ul>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Energy Goals</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Weekly Goal (18 kWh)</span>
                      <span className="text-sm text-green-500">73% Complete</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-green-500" 
                        style={{ width: "73%" }}
                      ></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Monthly Goal (75 kWh)</span>
                      <span className="text-sm text-green-500">42% Complete</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-green-500" 
                        style={{ width: "42%" }}
                      ></div>
                    </div>
                  </div>
                  
                  <Button variant="outline" className="w-full mt-2">
                    Set New Goal
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="devices" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Energy Usage by Device</CardTitle>
              <CardDescription>
                See which devices are consuming the most energy
              </CardDescription>
            </CardHeader>
            <CardContent>
              <EnergyChart 
                data={energyData}
                deviceBreakdown={deviceBreakdown}
                period={period}
                onPeriodChange={setPeriod}
              />
              
              <div className="mt-6 space-y-4">
                <h3 className="text-lg font-medium">Device Efficiency Ratings</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {devices.slice(0, 4).map((device) => (
                    <div key={device.id} className="flex items-center p-3 bg-card/80 rounded-lg border border-muted">
                      <div className={`w-10 h-10 rounded-full ${device.type === "light" ? "bg-accent/20" : "bg-primary/20"} flex items-center justify-center mr-3`}>
                        <i className={`${device.type === "light" ? "ri-lightbulb-line text-accent" : "ri-windy-line text-primary"} text-xl`}></i>
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between">
                          <span className="font-medium">{device.name}</span>
                          <span className="text-sm font-medium">{(Math.random() * 0.5 + 0.1).toFixed(2)} kWh/day</span>
                        </div>
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>Room: {device.roomId === 1 ? "Living Room" : device.roomId === 2 ? "Bedroom" : "Other"}</span>
                          <span className={device.status ? "text-green-500" : "text-muted-foreground"}>
                            {device.status ? "Active" : "Inactive"}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <Button variant="outline" className="w-full">
                  View All Devices
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="rooms" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Energy Usage by Room</CardTitle>
              <CardDescription>
                Understand which rooms consume the most energy
              </CardDescription>
            </CardHeader>
            <CardContent>
              <EnergyChart 
                data={energyData}
                deviceBreakdown={roomBreakdown}
                period={period}
                onPeriodChange={setPeriod}
              />
              
              <div className="mt-6">
                <h3 className="text-lg font-medium mb-4">Room Efficiency</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 bg-card/80 rounded-lg border border-muted">
                    <h4 className="font-medium">Living Room</h4>
                    <p className="text-sm text-muted-foreground mb-2">3 active devices, 45% of total usage</p>
                    <div className="h-1.5 bg-muted rounded-full overflow-hidden mt-1">
                      <div className="h-full bg-primary" style={{ width: "45%" }}></div>
                    </div>
                  </div>
                  
                  <div className="p-4 bg-card/80 rounded-lg border border-muted">
                    <h4 className="font-medium">Bedroom</h4>
                    <p className="text-sm text-muted-foreground mb-2">2 active devices, 25% of total usage</p>
                    <div className="h-1.5 bg-muted rounded-full overflow-hidden mt-1">
                      <div className="h-full bg-accent" style={{ width: "25%" }}></div>
                    </div>
                  </div>
                  
                  <div className="p-4 bg-card/80 rounded-lg border border-muted">
                    <h4 className="font-medium">Kitchen</h4>
                    <p className="text-sm text-muted-foreground mb-2">1 active device, 20% of total usage</p>
                    <div className="h-1.5 bg-muted rounded-full overflow-hidden mt-1">
                      <div className="h-full bg-green-500" style={{ width: "20%" }}></div>
                    </div>
                  </div>
                  
                  <div className="p-4 bg-card/80 rounded-lg border border-muted">
                    <h4 className="font-medium">Other Rooms</h4>
                    <p className="text-sm text-muted-foreground mb-2">2 active devices, 10% of total usage</p>
                    <div className="h-1.5 bg-muted rounded-full overflow-hidden mt-1">
                      <div className="h-full bg-blue-500" style={{ width: "10%" }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="history" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Historical Energy Usage</CardTitle>
              <CardDescription>
                View your energy consumption trends over time
              </CardDescription>
            </CardHeader>
            <CardContent>
              <EnergyChart 
                data={energyData}
                deviceBreakdown={deviceBreakdown}
                period={period}
                onPeriodChange={setPeriod}
              />
              
              <div className="mt-6">
                <h3 className="text-lg font-medium mb-4">Energy Usage Comparison</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 bg-card/80 rounded-lg border border-muted text-center">
                    <h4 className="text-sm text-muted-foreground">This Week</h4>
                    <p className="text-2xl font-bold mt-1">13.2 kWh</p>
                    <span className="text-xs text-green-500">12% lower than avg</span>
                  </div>
                  
                  <div className="p-4 bg-card/80 rounded-lg border border-muted text-center">
                    <h4 className="text-sm text-muted-foreground">Last Month</h4>
                    <p className="text-2xl font-bold mt-1">68.5 kWh</p>
                    <span className="text-xs text-green-500">8% lower than avg</span>
                  </div>
                  
                  <div className="p-4 bg-card/80 rounded-lg border border-muted text-center">
                    <h4 className="text-sm text-muted-foreground">Year to Date</h4>
                    <p className="text-2xl font-bold mt-1">287 kWh</p>
                    <span className="text-xs text-green-500">15% lower than last year</span>
                  </div>
                </div>
                
                <Button variant="outline" className="w-full mt-4">
                  Download Energy Report
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
