import { useState, useEffect } from "react";
import { 
  TemperatureCard, 
  EnergyCard, 
  DevicesCard, 
  ComfortCard 
} from "@/components/dashboard/StatusCard";
import { EnergyChart } from "@/components/dashboard/EnergyChart";
import DeviceCard from "@/components/devices/DeviceCard";
import AutomationRule from "@/components/automation/AutomationRule";
import { AIAssistant } from "@/components/ai/AIAssistant";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Room, Device, Rule } from "@shared/schema";
import { calculateComfortScore, calculateEnergyUsage } from "@/lib/deviceUtils";

export default function Dashboard() {
  // State variables to replace the context
  const [devices, setDevices] = useState<Device[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [rules, setRules] = useState<Rule[]>([]);
  const [user, setUser] = useState<{name: string; role: string}>({name: "Alex", role: "Admin"});
  const [selectedRoom, setSelectedRoom] = useState(1); // Default to first room
  const [temperature] = useState(24);
  const [humidity] = useState(72);
  const [mqttConnected] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  
  const { toast } = useToast();
  
  // Load data directly from API
  useEffect(() => {
    const loadData = async () => {
      try {
        // Load rooms
        const roomsResponse = await fetch('/api/rooms');
        const roomsData = await roomsResponse.json();
        setRooms(roomsData);
        
        // Load devices
        const devicesResponse = await fetch('/api/devices');
        const devicesData = await devicesResponse.json();
        setDevices(devicesData);
        
        // Load rules
        const rulesResponse = await fetch('/api/rules');
        const rulesData = await rulesResponse.json();
        setRules(rulesData);
        
        // Load user
        const usersResponse = await fetch('/api/users');
        const usersData = await usersResponse.json();
        if (usersData && usersData.length > 0) {
          setUser({
            name: usersData[0].name || "Alex",
            role: usersData[0].role || "Admin"
          });
        }
        
        setLastUpdate(new Date());
      } catch (error) {
        console.error('Error loading data:', error);
        toast({
          title: "Error",
          description: "Failed to load data. Please try again.",
          variant: "destructive",
        });
      }
    };
    
    loadData();
  }, [toast]);

  // Compute derived values
  const activeDevices = devices.filter(device => device.status);
  const activeLights = activeDevices.filter(device => device.type === "light");
  const activeFans = activeDevices.filter(device => device.type === "fan");
  const energyUsage = calculateEnergyUsage(devices);
  const comfortScore = calculateComfortScore(devices, temperature, humidity);
  
  // Utility functions
  const getDevicesByRoom = (roomId: number) => 
    devices.filter(device => device.roomId === roomId);
    
  const roomDevices = getDevicesByRoom(selectedRoom);
  
  // Create mock energy data for chart
  const hourlyData = Array.from({ length: 7 }, (_, i) => {
    const hour = new Date().getHours() - 6 + i;
    const formattedHour = hour < 0 
      ? `${24 + hour}:00` 
      : hour >= 24 
        ? `${hour - 24}:00` 
        : `${hour}:00`;
    
    return {
      time: formattedHour,
      value: Math.random() * 2 + 1, // Between 1-3 kW
    };
  });
  
  // Energy breakdown data
  const deviceBreakdown = [
    { name: "Lighting", value: 0.8, color: "hsl(var(--primary))", percentage: 33 },
    { name: "Fans", value: 1.2, color: "hsl(217, 91%, 60%)", percentage: 50 },
    { name: "Other Devices", value: 0.4, color: "hsl(142, 76%, 36%)", percentage: 17 },
  ];

  // Handle add room button
  const handleAddRoom = () => {
    toast({
      title: "Feature not available",
      description: "Adding new rooms is not available in the demo version.",
    });
  };

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto">
      {/* Header section */}
      <div className="mb-6">
        <h1 className="text-2xl md:text-3xl font-bold">Welcome Home, {user?.name?.split(' ')[0] || "Alex"}</h1>
        <p className="text-muted-foreground mt-1">Your home is running efficiently today. Energy usage is 12% lower than usual.</p>
      </div>

      {/* Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <TemperatureCard temperature={temperature} humidity={humidity} />
        <EnergyCard 
          usage={energyUsage} 
          weeklyGoal={18} 
          currentWeekUsage={13.2} 
        />
        <DevicesCard />
        <ComfortCard 
          score={comfortScore.score}
          tempScore={comfortScore.tempScore}
          lightScore={comfortScore.lightScore}
        />
      </div>

      {/* Room Controls section */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">Room Controls</h2>
          <Button 
            variant="default" 
            size="sm"
            onClick={handleAddRoom}
            className="flex items-center"
          >
            <i className="ri-add-line mr-1"></i> Add Room
          </Button>
        </div>

        {/* Room tabs */}
        <div className="flex space-x-2 overflow-x-auto pb-3 mb-4 scrollbar-thin">
          {rooms.map(room => (
            <Button
              key={room.id}
              variant={selectedRoom === room.id ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedRoom(room.id)}
              className="whitespace-nowrap"
            >
              {room.name}
            </Button>
          ))}
        </div>

        {/* Room visualization */}
        <div className="bg-card p-5 rounded-xl shadow-md mb-6">
          {/* Room header */}
          <div className="flex flex-wrap justify-between items-center mb-4">
            <h3 className="text-lg font-semibold">{rooms.find(r => r.id === selectedRoom)?.name || "Room"}</h3>
            <div className="flex space-x-3">
              <Button variant="ghost" size="sm" className="flex items-center">
                <i className="ri-settings-3-line mr-1"></i> Configure
              </Button>
              <Button variant="default" size="sm" className="flex items-center">
                <i className="ri-save-line mr-1"></i> Save Scene
              </Button>
            </div>
          </div>

          {/* Room device grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {roomDevices.map(device => (
              <DeviceCard key={device.id} device={device} />
            ))}
            
            {roomDevices.length === 0 && (
              <div className="col-span-3 text-center py-10 text-muted-foreground">
                No devices in this room. Add a device to get started.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* AI Assistant Section */}
      <div className="mb-8">
        <AIAssistant />
      </div>

      {/* Energy Usage & Scheduling section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Energy Usage */}
        <EnergyChart 
          data={hourlyData}
          deviceBreakdown={deviceBreakdown}
          period="day"
          onPeriodChange={(period) => console.log("Period changed:", period)}
        />

        {/* Automation Rules */}
        <div className="bg-card p-5 rounded-xl shadow-md">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold">Automation Rules</h3>
            <Button variant="default" size="sm" className="flex items-center">
              <i className="ri-add-line mr-1"></i> New Rule
            </Button>
          </div>

          {/* Automation Rules List */}
          <div className="space-y-3">
            {rules.slice(0, 3).map(rule => (
              <AutomationRule key={rule.id} rule={rule} />
            ))}
          </div>

          <Button 
            variant="ghost" 
            className="w-full mt-4 py-2 text-center text-muted-foreground hover:text-foreground text-sm border border-dashed border-muted"
          >
            View All Automation Rules
          </Button>
        </div>
      </div>

      {/* MQTT Connection Status */}
      <div className="bg-card p-4 rounded-xl shadow-md mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className={`h-3 w-3 rounded-full ${mqttConnected ? 'bg-green-500' : 'bg-red-500'} mr-2`}></div>
            <span className="text-sm">MQTT Connection: {mqttConnected ? 'Active' : 'Disconnected'}</span>
          </div>
          <div className="text-xs text-muted-foreground">
            Last update: {lastUpdate ? `${Math.floor((Date.now() - lastUpdate.getTime()) / 1000)} seconds ago` : 'never'}
          </div>
        </div>
        <div className="mt-2 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-xs text-muted-foreground bg-background rounded p-2">
            <span className="font-mono">broker: mqtt.smarthome.local</span>
          </div>
          <div className="text-xs text-muted-foreground bg-background rounded p-2">
            <span className="font-mono">connected devices: {activeDevices.length}</span>
          </div>
          <div className="text-xs text-muted-foreground bg-background rounded p-2">
            <span className="font-mono">message frequency: 0.5Hz</span>
          </div>
        </div>
      </div>
    </div>
  );
}
