import { useState, useEffect } from "react";
import DeviceCard from "@/components/devices/DeviceCard";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Device, Room } from "@shared/schema";

export default function Fans() {
  const [devices, setDevices] = useState<Device[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [temperature, setTemperature] = useState<number>(24);
  const [humidity, setHumidity] = useState<number>(45);
  const [selectedRoom, setSelectedRoom] = useState<number | null>(null);
  const { toast } = useToast();
  
  // Load data directly from API
  useEffect(() => {
    const loadData = async () => {
      try {
        // Load rooms
        const roomsResponse = await fetch('/api/rooms');
        const roomsData = await roomsResponse.json();
        setRooms(roomsData);
        
        // Load devices
        const devicesResponse = await fetch('/api/devices');
        const devicesData = await devicesResponse.json();
        setDevices(devicesData);
        
        // We could load environment data from API if available
        // For now just use sample values
        setTemperature(Math.floor(Math.random() * 8) + 21); // Random between 21-28°C
        setHumidity(Math.floor(Math.random() * 30) + 35);   // Random between 35-65%
      } catch (error) {
        console.error('Error loading data:', error);
        toast({
          title: "Error",
          description: "Failed to load data. Please try again.",
          variant: "destructive",
        });
      }
    };
    
    loadData();
  }, [toast]);

  // Filter for fan devices only
  const fanDevices = devices.filter(device => device.type === "fan");
  
  // Filter by selected room if one is selected
  const filteredDevices = selectedRoom 
    ? fanDevices.filter(device => device.roomId === selectedRoom)
    : fanDevices;
  
  // Count active fans
  const activeFans = fanDevices.filter(device => device.status).length;
  
  // Handle add device button
  const handleAddDevice = () => {
    toast({
      title: "Feature not available",
      description: "Adding new devices is not available in the demo version.",
    });
  };

  // Get fan speed recommendation based on temperature
  const getRecommendedFanSpeed = () => {
    if (temperature < 20) return "Low or Off";
    if (temperature < 24) return "Low";
    if (temperature < 27) return "Medium";
    return "High";
  };

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto">
      {/* Header section */}
      <div className="mb-6">
        <h1 className="text-2xl md:text-3xl font-bold">Fans & Climate Control</h1>
        <p className="text-muted-foreground mt-1">
          Manage all your fan devices from a single dashboard. Currently {activeFans} of {fanDevices.length} fans are active.
        </p>
      </div>
      
      {/* Climate status */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Current Climate</CardTitle>
          <CardDescription>
            Current temperature and humidity readings from your home sensors
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-card/80 p-4 rounded-lg flex flex-col items-center">
              <span className="text-sm text-muted-foreground">Temperature</span>
              <span className="text-3xl font-bold mt-1">{temperature}°C</span>
            </div>
            
            <div className="bg-card/80 p-4 rounded-lg flex flex-col items-center">
              <span className="text-sm text-muted-foreground">Humidity</span>
              <span className="text-3xl font-bold mt-1">{humidity}%</span>
            </div>
            
            <div className="bg-card/80 p-4 rounded-lg flex flex-col items-center">
              <span className="text-sm text-muted-foreground">Recommended Fan Speed</span>
              <span className="text-3xl font-bold mt-1">{getRecommendedFanSpeed()}</span>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Room filter */}
      <div className="mb-6">
        <h2 className="text-lg font-medium mb-3">Filter by Room</h2>
        <div className="flex flex-wrap gap-2">
          <Button
            variant={selectedRoom === null ? "default" : "outline"}
            onClick={() => setSelectedRoom(null)}
          >
            All Rooms
          </Button>
          
          {rooms.map(room => (
            <Button
              key={room.id}
              variant={selectedRoom === room.id ? "default" : "outline"}
              onClick={() => setSelectedRoom(room.id)}
            >
              {room.name}
            </Button>
          ))}
        </div>
      </div>
      
      {/* Devices grid */}
      <Card className="mb-6">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Fan Devices</CardTitle>
          <Button variant="default" size="sm" onClick={handleAddDevice}>
            <i className="ri-add-line mr-1"></i> Add Fan
          </Button>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredDevices.map(device => (
              <DeviceCard key={device.id} device={device} />
            ))}
            
            {filteredDevices.length === 0 && (
              <div className="col-span-3 text-center py-10 text-muted-foreground">
                No fan devices found. Add a device or select a different room.
              </div>
            )}
          </div>
        </CardContent>
      </Card>
      
      {/* Fan automation */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Climate Automation</CardTitle>
          <Button variant="outline" size="sm">
            <i className="ri-add-line mr-1"></i> Create Rule
          </Button>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-card/80 rounded-lg border border-muted">
              <h3 className="font-medium mb-2">Temperature-based Control</h3>
              <p className="text-sm text-muted-foreground mb-3">
                Automatically adjust fan speeds based on room temperature.
              </p>
              <div className="flex justify-between items-center">
                <span className="text-sm">Status: Active</span>
                <Button variant="outline" size="sm">Configure</Button>
              </div>
            </div>
            
            <div className="p-4 bg-card/80 rounded-lg border border-muted">
              <h3 className="font-medium mb-2">Scheduled Fan Control</h3>
              <p className="text-sm text-muted-foreground mb-3">
                Run fans at specific times with pre-set speed and mode.
              </p>
              <div className="flex justify-between items-center">
                <span className="text-sm">Status: Inactive</span>
                <Button variant="outline" size="sm">Configure</Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
