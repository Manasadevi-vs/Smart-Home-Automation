import { useState, useEffect } from "react";
import DeviceCard from "@/components/devices/DeviceCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Device, Room } from "@shared/schema";

export default function Lighting() {
  const [devices, setDevices] = useState<Device[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [selectedRoom, setSelectedRoom] = useState<number | null>(null);
  const { toast } = useToast();
  
  // Load data directly from API
  useEffect(() => {
    const loadData = async () => {
      try {
        // Load rooms
        const roomsResponse = await fetch('/api/rooms');
        const roomsData = await roomsResponse.json();
        setRooms(roomsData);
        
        // Load devices
        const devicesResponse = await fetch('/api/devices');
        const devicesData = await devicesResponse.json();
        setDevices(devicesData);
      } catch (error) {
        console.error('Error loading data:', error);
        toast({
          title: "Error",
          description: "Failed to load data. Please try again.",
          variant: "destructive",
        });
      }
    };
    
    loadData();
  }, [toast]);

  // Filter for light devices only
  const lightDevices = devices.filter(device => device.type === "light");
  
  // Filter by selected room if one is selected
  const filteredDevices = selectedRoom 
    ? lightDevices.filter(device => device.roomId === selectedRoom)
    : lightDevices;
  
  // Count active lights
  const activeLights = lightDevices.filter(device => device.status).length;
  
  // Handle add device button
  const handleAddDevice = () => {
    toast({
      title: "Feature not available",
      description: "Adding new devices is not available in the demo version.",
    });
  };

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto">
      {/* Header section */}
      <div className="mb-6">
        <h1 className="text-2xl md:text-3xl font-bold">Lighting Control</h1>
        <p className="text-muted-foreground mt-1">
          Manage all your lighting devices from a single dashboard. Currently {activeLights} of {lightDevices.length} lights are active.
        </p>
      </div>
      
      {/* Room filter */}
      <div className="mb-6">
        <h2 className="text-lg font-medium mb-3">Filter by Room</h2>
        <div className="flex flex-wrap gap-2">
          <Button
            variant={selectedRoom === null ? "default" : "outline"}
            onClick={() => setSelectedRoom(null)}
          >
            All Rooms
          </Button>
          
          {rooms.map(room => (
            <Button
              key={room.id}
              variant={selectedRoom === room.id ? "default" : "outline"}
              onClick={() => setSelectedRoom(room.id)}
            >
              {room.name}
            </Button>
          ))}
        </div>
      </div>
      
      {/* Devices grid */}
      <Card className="mb-6">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Light Devices</CardTitle>
          <Button variant="default" size="sm" onClick={handleAddDevice}>
            <i className="ri-add-line mr-1"></i> Add Light
          </Button>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredDevices.map(device => (
              <DeviceCard key={device.id} device={device} />
            ))}
            
            {filteredDevices.length === 0 && (
              <div className="col-span-3 text-center py-10 text-muted-foreground">
                No light devices found. Add a device or select a different room.
              </div>
            )}
          </div>
        </CardContent>
      </Card>
      
      {/* Lighting scenes */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Lighting Scenes</CardTitle>
          <Button variant="outline" size="sm">
            <i className="ri-add-line mr-1"></i> Create Scene
          </Button>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button 
              variant="outline" 
              className="h-20 flex flex-col items-center justify-center bg-card/80 hover:bg-muted"
            >
              <i className="ri-sun-line text-xl mb-1 text-yellow-500"></i>
              <span>Daylight</span>
            </Button>
            
            <Button 
              variant="outline" 
              className="h-20 flex flex-col items-center justify-center bg-card/80 hover:bg-muted"
            >
              <i className="ri-movie-line text-xl mb-1 text-blue-500"></i>
              <span>Movie Night</span>
            </Button>
            
            <Button 
              variant="outline" 
              className="h-20 flex flex-col items-center justify-center bg-card/80 hover:bg-muted"
            >
              <i className="ri-moon-clear-line text-xl mb-1 text-purple-500"></i>
              <span>Evening</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
