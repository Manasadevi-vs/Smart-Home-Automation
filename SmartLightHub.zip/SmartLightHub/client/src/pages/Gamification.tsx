import { useState, useEffect } from "react";
import { 
  Card,
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription,
  CardFooter 
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Progress 
} from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { User } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

// Component for user level progress
function UserLevel({ profile }: { profile: any }) {
  return (
    <Card className="mb-6">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-center">
          <CardTitle className="text-xl mb-1">Level {profile.nextLevel.current}</CardTitle>
          <div className="text-2xl font-bold bg-gradient-to-r from-primary to-purple-500 text-transparent bg-clip-text">
            {profile.user.points} Points
          </div>
        </div>
        <CardDescription>
          {profile.nextLevel.pointsToNext} points to Level {profile.nextLevel.current + 1}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Progress value={profile.nextLevel.progress * 100} className="h-3" />
      </CardContent>
      <CardFooter className="pt-0 flex justify-between text-sm text-muted-foreground">
        <div>Current: Level {profile.nextLevel.current}</div>
        <div>Next: Level {profile.nextLevel.current + 1}</div>
      </CardFooter>
    </Card>
  );
}

// Component for displaying a single achievement
function AchievementCard({ achievement, progress = 0, completed = false }: { 
  achievement: any, 
  progress?: number, 
  completed?: boolean 
}) {
  return (
    <Card className={completed ? "border-primary/30 bg-primary/5" : ""}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center mb-1">
          <CardTitle className="text-base">{achievement.name}</CardTitle>
          {completed && (
            <Badge variant="outline" className="bg-primary/20 text-primary border-primary/30">
              Completed
            </Badge>
          )}
        </div>
        <CardDescription>{achievement.description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center mb-2">
          <div className="mr-3 w-8 h-8 rounded-full bg-muted flex items-center justify-center">
            <i className={`ri-${achievement.icon || 'award-line'} text-lg ${completed ? 'text-primary' : ''}`}></i>
          </div>
          <div className="flex-1">
            <Progress 
              value={completed ? 100 : (progress / achievement.requirement) * 100} 
              className="h-2" 
            />
          </div>
          <div className="ml-3 text-sm font-medium">
            {progress}/{achievement.requirement}
          </div>
        </div>
        {!completed && (
          <div className="text-xs text-muted-foreground mt-1">
            Reward: {achievement.pointsAwarded} points
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// Component for displaying a single challenge
function ChallengeCard({ challenge, progress = 0, completed = false }: { 
  challenge: any, 
  progress?: number, 
  completed?: boolean 
}) {
  // Calculate days left to complete the challenge
  const endDate = new Date(challenge.endDate);
  const now = new Date();
  const daysLeft = Math.max(0, Math.ceil((endDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));
  
  return (
    <Card className={completed ? "border-primary/30 bg-primary/5" : ""}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center mb-1">
          <CardTitle className="text-base">{challenge.name}</CardTitle>
          {completed ? (
            <Badge variant="outline" className="bg-primary/20 text-primary border-primary/30">
              Completed
            </Badge>
          ) : (
            <Badge variant="outline" className="bg-amber-500/10 text-amber-500 border-amber-500/20">
              {daysLeft} days left
            </Badge>
          )}
        </div>
        <CardDescription>{challenge.description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center mb-2">
          <div className="mr-3 w-8 h-8 rounded-full bg-muted flex items-center justify-center">
            <i className={`ri-${challenge.icon || 'award-line'} text-lg ${completed ? 'text-primary' : ''}`}></i>
          </div>
          <div className="flex-1">
            <Progress 
              value={completed ? 100 : (progress / challenge.requirement) * 100} 
              className="h-2" 
            />
          </div>
          <div className="ml-3 text-sm font-medium">
            {progress}/{challenge.requirement}
          </div>
        </div>
        {!completed && (
          <div className="text-xs text-muted-foreground mt-1">
            Reward: {challenge.pointsAwarded} points
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// Loading skeleton for gamification items
function SkeletonItem() {
  return (
    <Card>
      <CardHeader className="pb-2">
        <Skeleton className="h-5 w-3/4 mb-2" />
        <Skeleton className="h-4 w-full" />
      </CardHeader>
      <CardContent>
        <div className="flex items-center mb-2">
          <Skeleton className="mr-3 w-8 h-8 rounded-full" />
          <div className="flex-1">
            <Skeleton className="h-2 w-full" />
          </div>
          <Skeleton className="ml-3 h-4 w-10" />
        </div>
      </CardContent>
    </Card>
  );
}

export default function Gamification() {
  const { toast } = useToast();
  const [profile, setProfile] = useState<any>(null);
  const [achievements, setAchievements] = useState<any[]>([]);
  const [challenges, setChallenges] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("achievements");

  // Fetch user gamification profile
  useEffect(() => {
    const fetchGamificationData = async () => {
      try {
        setLoading(true);
        
        // Default user ID for demo purposes
        const userId = 1;
        
        // Fetch profile data
        const profileResponse = await fetch(`/api/gamification/profile/${userId}`);
        const profileData = await profileResponse.json();
        
        // Fetch achievements data
        const achievementsResponse = await fetch(`/api/gamification/achievements/${userId}`);
        const achievementsData = await achievementsResponse.json();
        
        // Fetch challenges data
        const challengesResponse = await fetch(`/api/gamification/challenges/${userId}`);
        const challengesData = await challengesResponse.json();
        
        setProfile(profileData);
        setAchievements(achievementsData);
        setChallenges(challengesData);
      } catch (error) {
        console.error("Error fetching gamification data:", error);
        toast({
          title: "Error",
          description: "Failed to load gamification data. Please try again.",
          variant: "destructive"
        });
      } finally {
        setLoading(false);
      }
    };
    
    fetchGamificationData();
  }, [toast]);

  return (
    <div className="container mx-auto p-4">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold mb-1">Gamification</h1>
          <p className="text-muted-foreground">Track your achievements, complete challenges, and level up!</p>
        </div>
        
        {profile && !loading && (
          <div className="flex items-center mt-4 md:mt-0 bg-muted px-4 py-2 rounded-lg">
            <div className="mr-3">
              <p className="text-sm font-medium">Daily Streak</p>
              <p className="text-xs text-muted-foreground">Keep it going!</p>
            </div>
            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold">
              {profile.streak}
            </div>
          </div>
        )}
      </div>
      
      {loading ? (
        <Skeleton className="w-full h-24 mb-6" />
      ) : profile ? (
        <UserLevel profile={profile} />
      ) : null}
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="achievements">
            Achievements
            {!loading && profile && (
              <Badge className="ml-2 bg-muted text-muted-foreground">
                {profile.achievements.completed}/{profile.achievements.total}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="challenges">
            Challenges
            {!loading && profile && (
              <Badge className="ml-2 bg-muted text-muted-foreground">
                {profile.challenges.completed}/{profile.challenges.active}
              </Badge>
            )}
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="achievements" className="mt-0">
          <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            {loading ? (
              // Display loading skeletons
              [...Array(6)].map((_, i) => <SkeletonItem key={i} />)
            ) : achievements.length > 0 ? (
              // Display achievements sorted by completion status and tier
              [...achievements]
                .sort((a, b) => {
                  // Sort completed achievements first
                  if (a.completed && !b.completed) return -1;
                  if (!a.completed && b.completed) return 1;
                  
                  // If both completed or both incomplete, sort by tier
                  return (a.achievement.tier || 1) - (b.achievement.tier || 1);
                })
                .map((item) => (
                  <AchievementCard 
                    key={item.achievement.id} 
                    achievement={item.achievement} 
                    progress={item.progress} 
                    completed={item.completed} 
                  />
                ))
            ) : (
              <div className="col-span-full text-center py-10">
                <div className="text-5xl mb-3">🏆</div>
                <h3 className="text-lg font-medium mb-1">No achievements found</h3>
                <p className="text-muted-foreground">Start using your smart home to earn achievements!</p>
              </div>
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="challenges" className="mt-0">
          <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            {loading ? (
              // Display loading skeletons
              [...Array(6)].map((_, i) => <SkeletonItem key={i} />)
            ) : challenges.length > 0 ? (
              // Display challenges sorted by completion and end date
              [...challenges]
                .sort((a, b) => {
                  // Sort completed challenges first
                  if (a.completed && !b.completed) return -1;
                  if (!a.completed && b.completed) return 1;
                  
                  // If both completed or both incomplete, sort by end date
                  return new Date(a.challenge.endDate).getTime() - new Date(b.challenge.endDate).getTime();
                })
                .map((item) => (
                  <ChallengeCard 
                    key={item.challenge.id} 
                    challenge={item.challenge} 
                    progress={item.progress} 
                    completed={item.completed} 
                  />
                ))
            ) : (
              <div className="col-span-full text-center py-10">
                <div className="text-5xl mb-3">🎯</div>
                <h3 className="text-lg font-medium mb-1">No active challenges</h3>
                <p className="text-muted-foreground">Check back later for new challenges!</p>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}