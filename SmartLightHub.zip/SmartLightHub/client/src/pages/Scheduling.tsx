import { useState, useEffect } from "react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription,
  CardFooter
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import AutomationRule from "@/components/automation/AutomationRule";
import { useToast } from "@/hooks/use-toast";
import { Rule, Room, Device } from "@shared/schema";

export default function Scheduling() {
  const [rules, setRules] = useState<Rule[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [devices, setDevices] = useState<Device[]>([]);
  const [activeTab, setActiveTab] = useState("rules");
  const { toast } = useToast();
  
  // Load data directly from API
  useEffect(() => {
    const loadData = async () => {
      try {
        // Load rules
        const rulesResponse = await fetch('/api/rules');
        const rulesData = await rulesResponse.json();
        setRules(rulesData);
        
        // Load rooms
        const roomsResponse = await fetch('/api/rooms');
        const roomsData = await roomsResponse.json();
        setRooms(roomsData);
        
        // Load devices
        const devicesResponse = await fetch('/api/devices');
        const devicesData = await devicesResponse.json();
        setDevices(devicesData);
      } catch (error) {
        console.error('Error loading data:', error);
        toast({
          title: "Error",
          description: "Failed to load data. Please try again.",
          variant: "destructive",
        });
      }
    };
    
    loadData();
  }, [toast]);

  // Filter rules by active status
  const activeRules = rules.filter(rule => rule.isActive);
  const inactiveRules = rules.filter(rule => !rule.isActive);

  // Group by type
  const timeBasedRules = rules.filter(rule => rule.trigger === "time");
  const manualRules = rules.filter(rule => rule.trigger === "manual");

  const handleCreateRule = () => {
    toast({
      title: "Feature not available",
      description: "Creating new rules is not available in the demo version.",
    });
  };

  const handleCreateSchedule = () => {
    toast({
      title: "Feature not available",
      description: "Creating new schedules is not available in the demo version.",
    });
  };

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto">
      {/* Header section */}
      <div className="mb-6">
        <h1 className="text-2xl md:text-3xl font-bold">Automation & Scheduling</h1>
        <p className="text-muted-foreground mt-1">
          Manage your smart home automation rules and schedules for lighting and fans.
        </p>
      </div>
      
      {/* Status Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col gap-1">
              <span className="text-muted-foreground text-sm">Active Rules</span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-bold">{activeRules.length}</span>
                <span className="text-muted-foreground text-xs">of {rules.length} total</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col gap-1">
              <span className="text-muted-foreground text-sm">Time-based Rules</span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-bold">{timeBasedRules.length}</span>
                <span className="text-muted-foreground text-xs">{timeBasedRules.filter(r => r.isActive).length} active</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col gap-1">
              <span className="text-muted-foreground text-sm">Manual Scenes</span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-bold">{manualRules.length}</span>
                <span className="text-muted-foreground text-xs">{manualRules.filter(r => r.isActive).length} active</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Tabs for different views */}
      <Tabs 
        defaultValue="rules" 
        value={activeTab}
        onValueChange={setActiveTab}
        className="mb-6"
      >
        <TabsList>
          <TabsTrigger value="rules">Automation Rules</TabsTrigger>
          <TabsTrigger value="schedules">Daily Schedules</TabsTrigger>
          <TabsTrigger value="scenes">Scenes</TabsTrigger>
        </TabsList>
        
        <TabsContent value="rules" className="mt-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div>
                <CardTitle>Automation Rules</CardTitle>
                <CardDescription>
                  Rules that automatically control your devices based on conditions
                </CardDescription>
              </div>
              <Button onClick={handleCreateRule}>
                <i className="ri-add-line mr-1"></i> New Rule
              </Button>
            </CardHeader>
            
            <CardContent>
              <div className="space-y-3">
                {rules.map(rule => (
                  <AutomationRule key={rule.id} rule={rule} />
                ))}
                
                {rules.length === 0 && (
                  <div className="text-center py-10 text-muted-foreground">
                    No automation rules found. Create a rule to get started.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="schedules" className="mt-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div>
                <CardTitle>Daily Schedules</CardTitle>
                <CardDescription>
                  Set schedules for your devices to run at specific times
                </CardDescription>
              </div>
              <Button onClick={handleCreateSchedule}>
                <i className="ri-add-line mr-1"></i> New Schedule
              </Button>
            </CardHeader>
            
            <CardContent>
              <div className="space-y-4">
                {/* Morning Schedule */}
                <div className="p-4 bg-card/80 rounded-lg border border-muted">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">Morning Schedule</h3>
                        <Badge variant="outline" className="bg-yellow-500/10 text-yellow-500 hover:bg-yellow-500/20">
                          <i className="ri-sun-line mr-1"></i> Morning
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">Runs at 7:00 AM on weekdays</p>
                    </div>
                    <Switch checked={true} />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-2">
                    <div className="flex flex-col gap-1 text-sm">
                      <span className="text-muted-foreground text-xs">Devices</span>
                      <div className="flex flex-wrap gap-1">
                        <Badge variant="secondary" className="text-xs">Bedroom Light</Badge>
                        <Badge variant="secondary" className="text-xs">Living Room Light</Badge>
                        <Badge variant="secondary" className="text-xs">Bathroom Fan</Badge>
                      </div>
                    </div>
                    
                    <div className="flex flex-col gap-1 text-sm">
                      <span className="text-muted-foreground text-xs">Days</span>
                      <div className="flex gap-1">
                        <Badge variant="outline" className="text-xs">Mon</Badge>
                        <Badge variant="outline" className="text-xs">Tue</Badge>
                        <Badge variant="outline" className="text-xs">Wed</Badge>
                        <Badge variant="outline" className="text-xs">Thu</Badge>
                        <Badge variant="outline" className="text-xs">Fri</Badge>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex justify-end mt-2">
                    <Button variant="ghost" size="sm">Edit</Button>
                  </div>
                </div>
                
                {/* Evening Schedule */}
                <div className="p-4 bg-card/80 rounded-lg border border-muted">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">Evening Schedule</h3>
                        <Badge variant="outline" className="bg-purple-500/10 text-purple-500 hover:bg-purple-500/20">
                          <i className="ri-moon-line mr-1"></i> Evening
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">Runs at sunset every day</p>
                    </div>
                    <Switch checked={true} />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-2">
                    <div className="flex flex-col gap-1 text-sm">
                      <span className="text-muted-foreground text-xs">Devices</span>
                      <div className="flex flex-wrap gap-1">
                        <Badge variant="secondary" className="text-xs">All Lights (Warm)</Badge>
                        <Badge variant="secondary" className="text-xs">Living Room 60%</Badge>
                        <Badge variant="secondary" className="text-xs">Ceiling Fan (Low)</Badge>
                      </div>
                    </div>
                    
                    <div className="flex flex-col gap-1 text-sm">
                      <span className="text-muted-foreground text-xs">Days</span>
                      <div className="flex gap-1">
                        <Badge variant="outline" className="text-xs">All Days</Badge>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex justify-end mt-2">
                    <Button variant="ghost" size="sm">Edit</Button>
                  </div>
                </div>
                
                {/* Sleep Schedule */}
                <div className="p-4 bg-card/80 rounded-lg border border-muted">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">Sleep Schedule</h3>
                        <Badge variant="outline" className="bg-blue-500/10 text-blue-500 hover:bg-blue-500/20">
                          <i className="ri-zzz-line mr-1"></i> Night
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">Runs at 11:00 PM every day</p>
                    </div>
                    <Switch checked={false} />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-2">
                    <div className="flex flex-col gap-1 text-sm">
                      <span className="text-muted-foreground text-xs">Devices</span>
                      <div className="flex flex-wrap gap-1">
                        <Badge variant="secondary" className="text-xs">All Lights Off</Badge>
                        <Badge variant="secondary" className="text-xs">Bedroom Fan (Low)</Badge>
                      </div>
                    </div>
                    
                    <div className="flex flex-col gap-1 text-sm">
                      <span className="text-muted-foreground text-xs">Days</span>
                      <div className="flex gap-1">
                        <Badge variant="outline" className="text-xs">All Days</Badge>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex justify-end mt-2">
                    <Button variant="ghost" size="sm">Edit</Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="scenes" className="mt-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div>
                <CardTitle>Scenes</CardTitle>
                <CardDescription>
                  Quickly activate pre-defined settings for multiple devices
                </CardDescription>
              </div>
              <Button onClick={handleCreateRule}>
                <i className="ri-add-line mr-1"></i> New Scene
              </Button>
            </CardHeader>
            
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {/* Movie Night Scene */}
                <div className="p-4 bg-card/80 rounded-lg border border-muted flex flex-col">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="h-10 w-10 rounded-full bg-blue-500/20 flex items-center justify-center">
                      <i className="ri-movie-line text-blue-500"></i>
                    </div>
                    <h3 className="font-medium">Movie Night</h3>
                  </div>
                  
                  <p className="text-xs text-muted-foreground mb-3">
                    Dim lights and set perfect viewing ambiance
                  </p>
                  
                  <div className="text-xs text-muted-foreground mb-3">
                    <span>Includes:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      <Badge variant="outline" className="text-xs">Living Room (20%)</Badge>
                      <Badge variant="outline" className="text-xs">Ceiling Fan (Low)</Badge>
                    </div>
                  </div>
                  
                  <div className="mt-auto pt-2">
                    <Button variant="default" size="sm" className="w-full">
                      Activate
                    </Button>
                  </div>
                </div>
                
                {/* Reading Scene */}
                <div className="p-4 bg-card/80 rounded-lg border border-muted flex flex-col">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="h-10 w-10 rounded-full bg-green-500/20 flex items-center justify-center">
                      <i className="ri-book-open-line text-green-500"></i>
                    </div>
                    <h3 className="font-medium">Reading</h3>
                  </div>
                  
                  <p className="text-xs text-muted-foreground mb-3">
                    Bright, focused light for comfortable reading
                  </p>
                  
                  <div className="text-xs text-muted-foreground mb-3">
                    <span>Includes:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      <Badge variant="outline" className="text-xs">Floor Lamp (90%)</Badge>
                      <Badge variant="outline" className="text-xs">Ceiling Light (Off)</Badge>
                    </div>
                  </div>
                  
                  <div className="mt-auto pt-2">
                    <Button variant="default" size="sm" className="w-full">
                      Activate
                    </Button>
                  </div>
                </div>
                
                {/* Away Scene */}
                <div className="p-4 bg-card/80 rounded-lg border border-muted flex flex-col">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="h-10 w-10 rounded-full bg-red-500/20 flex items-center justify-center">
                      <i className="ri-run-line text-red-500"></i>
                    </div>
                    <h3 className="font-medium">Away Mode</h3>
                  </div>
                  
                  <p className="text-xs text-muted-foreground mb-3">
                    Save energy and simulate presence when away
                  </p>
                  
                  <div className="text-xs text-muted-foreground mb-3">
                    <span>Includes:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      <Badge variant="outline" className="text-xs">All Lights (Off)</Badge>
                      <Badge variant="outline" className="text-xs">All Fans (Off)</Badge>
                      <Badge variant="outline" className="text-xs">Random Lights (18:00-22:00)</Badge>
                    </div>
                  </div>
                  
                  <div className="mt-auto pt-2">
                    <Button variant="default" size="sm" className="w-full">
                      Activate
                    </Button>
                  </div>
                </div>
                
                {/* Add New Scene (placeholder) */}
                <div className="p-4 bg-card/80 rounded-lg border border-dashed border-muted flex flex-col items-center justify-center">
                  <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center mb-2">
                    <i className="ri-add-line"></i>
                  </div>
                  <h3 className="font-medium mb-1">Create New Scene</h3>
                  <p className="text-xs text-muted-foreground text-center mb-4">
                    Customize your own scene settings
                  </p>
                  <Button variant="outline" size="sm" onClick={handleCreateRule}>
                    Create Scene
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Schedule Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle>Suggested Automations</CardTitle>
          <CardDescription>
            Recommendations based on your usage patterns
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 bg-card/80 rounded-lg border border-muted">
              <div className="flex items-start gap-3">
                <div className="h-10 w-10 rounded-full bg-green-500/20 flex items-center justify-center mt-1">
                  <i className="ri-lightbulb-flash-line text-green-500"></i>
                </div>
                <div>
                  <h3 className="font-medium">Energy-Saving Night Mode</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    We noticed your lights stay on at night. Create a rule to turn off all lights at midnight?
                  </p>
                  <div className="flex gap-2 mt-3">
                    <Button variant="default" size="sm">Create Rule</Button>
                    <Button variant="ghost" size="sm">Dismiss</Button>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="p-4 bg-card/80 rounded-lg border border-muted">
              <div className="flex items-start gap-3">
                <div className="h-10 w-10 rounded-full bg-blue-500/20 flex items-center justify-center mt-1">
                  <i className="ri-windy-line text-blue-500"></i>
                </div>
                <div>
                  <h3 className="font-medium">Temperature-Adaptive Fan Control</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Automatically adjust fan speeds based on room temperature for better comfort.
                  </p>
                  <div className="flex gap-2 mt-3">
                    <Button variant="default" size="sm">Create Rule</Button>
                    <Button variant="ghost" size="sm">Dismiss</Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter className="border-t border-muted pt-4">
          <Button variant="outline" className="w-full">
            Generate More Suggestions
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
