import { useState, useEffect } from "react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription,
  CardFooter
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import ComfortSettings from "@/components/settings/ComfortSettings";
import { Badge } from "@/components/ui/badge";
import { User, Preference } from "@shared/schema";

export default function UserPreferences() {
  const [user, setUser] = useState<User | null>(null);
  const [preferences, setPreferences] = useState<Preference | null>(null);
  const [activeTab, setActiveTab] = useState("comfort");
  const { toast } = useToast();
  
  // Load data directly from API
  useEffect(() => {
    const loadData = async () => {
      try {
        // Load user
        const userResponse = await fetch('/api/users');
        const userData = await userResponse.json();
        if (userData && userData.length > 0) {
          setUser(userData[0]); // Just use the first user for demo
          
          // Load preferences for this user
          const preferencesResponse = await fetch(`/api/preferences/${userData[0].id}`);
          const preferencesData = await preferencesResponse.json();
          setPreferences(preferencesData);
        }
      } catch (error) {
        console.error('Error loading data:', error);
        toast({
          title: "Error",
          description: "Failed to load user preferences. Please try again.",
          variant: "destructive",
        });
      }
    };
    
    loadData();
  }, [toast]);
  
  // Function to update preferences
  const updatePreferences = async (userId: number, updates: Partial<Preference>) => {
    try {
      const response = await fetch(`/api/preferences/${userId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updates),
      });
      
      const updatedPreferences = await response.json();
      setPreferences(updatedPreferences);
      return updatedPreferences;
    } catch (error) {
      console.error('Error updating preferences:', error);
      toast({
        title: "Error",
        description: "Failed to update preferences. Please try again.",
        variant: "destructive",
      });
      return null;
    }
  };

  const handleSaveSettings = () => {
    toast({
      title: "Settings Saved",
      description: "Your preferences have been updated successfully.",
    });
  };

  // If preferences don't exist yet, show loading state
  if (!preferences) {
    return (
      <div className="p-4 md:p-6 max-w-7xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl md:text-3xl font-bold">User Preferences</h1>
          <p className="text-muted-foreground mt-1">Loading your comfort settings...</p>
        </div>
        
        <div className="h-64 flex items-center justify-center">
          <div className="text-muted-foreground animate-pulse">Loading preferences...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto">
      {/* Header section */}
      <div className="mb-6">
        <h1 className="text-2xl md:text-3xl font-bold">User Preferences</h1>
        <p className="text-muted-foreground mt-1">
          Customize your smart home experience to match your comfort needs.
        </p>
      </div>
      
      {/* Tabs for different settings */}
      <Tabs 
        defaultValue="comfort" 
        value={activeTab}
        onValueChange={setActiveTab}
        className="mb-6"
      >
        <TabsList>
          <TabsTrigger value="comfort">Comfort Settings</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="profile">User Profile</TabsTrigger>
          <TabsTrigger value="appearance">Appearance</TabsTrigger>
        </TabsList>
        
        <TabsContent value="comfort" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>User Comfort Preferences</CardTitle>
              <CardDescription>
                Adjust lighting and fan settings to match your comfort needs
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ComfortSettings preferences={preferences} />
            </CardContent>
            <CardFooter className="flex justify-between border-t pt-4">
              <Button variant="outline">Reset to Defaults</Button>
              <Button onClick={handleSaveSettings}>Save Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="notifications" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
              <CardDescription>
                Control when and how you receive alerts from your smart home
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Energy Usage Alerts</h3>
                  <p className="text-sm text-muted-foreground">Get notified when energy usage exceeds daily threshold</p>
                </div>
                <Switch checked={true} />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Device Status Changes</h3>
                  <p className="text-sm text-muted-foreground">Get notified when devices turn on/off unexpectedly</p>
                </div>
                <Switch checked={true} />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Comfort Recommendations</h3>
                  <p className="text-sm text-muted-foreground">Get suggestions for improving comfort based on your preferences</p>
                </div>
                <Switch checked={false} />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Schedule Execution</h3>
                  <p className="text-sm text-muted-foreground">Get notified when automated schedules are executed</p>
                </div>
                <Switch checked={false} />
              </div>
            </CardContent>
            <CardFooter className="flex justify-end border-t pt-4">
              <Button onClick={handleSaveSettings}>Save Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="profile" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>User Profile</CardTitle>
              <CardDescription>
                Manage your account information and preferences
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col space-y-1.5">
                <label className="text-sm font-medium">Name</label>
                <input 
                  className="p-2 rounded-md bg-card/80 border border-muted" 
                  value={user?.name || "Alex Johnson"} 
                  disabled 
                />
              </div>
              
              <div className="flex flex-col space-y-1.5">
                <label className="text-sm font-medium">Username</label>
                <input 
                  className="p-2 rounded-md bg-card/80 border border-muted" 
                  value={user?.username || "admin"} 
                  disabled 
                />
              </div>
              
              <div className="flex flex-col space-y-1.5">
                <label className="text-sm font-medium">Role</label>
                <input 
                  className="p-2 rounded-md bg-card/80 border border-muted" 
                  value={user?.role || "Admin"} 
                  disabled 
                />
              </div>
              
              <div className="flex flex-col space-y-1.5">
                <label className="text-sm font-medium">Default Dashboard</label>
                <select className="p-2 rounded-md bg-card/80 border border-muted">
                  <option>Main Dashboard</option>
                  <option>Energy Dashboard</option>
                  <option>Lighting Control</option>
                </select>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between border-t pt-4">
              <Button variant="outline">Change Password</Button>
              <Button onClick={handleSaveSettings}>Save Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="appearance" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Appearance Settings</CardTitle>
              <CardDescription>
                Customize how your smart home dashboard looks
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <h3 className="font-medium">Color Theme</h3>
                <div className="grid grid-cols-3 gap-2">
                  <div className="p-4 bg-card/80 border border-primary rounded-lg text-center cursor-pointer">
                    <div className="w-full h-6 bg-primary rounded mb-2"></div>
                    <span className="text-sm">Default</span>
                  </div>
                  
                  <div className="p-4 bg-card/80 border border-muted rounded-lg text-center cursor-pointer">
                    <div className="w-full h-6 bg-blue-500 rounded mb-2"></div>
                    <span className="text-sm">Blue</span>
                  </div>
                  
                  <div className="p-4 bg-card/80 border border-muted rounded-lg text-center cursor-pointer">
                    <div className="w-full h-6 bg-purple-500 rounded mb-2"></div>
                    <span className="text-sm">Purple</span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <h3 className="font-medium">Dashboard Layout</h3>
                <div className="grid grid-cols-2 gap-2">
                  <div className="p-4 bg-card/80 border border-primary rounded-lg text-center cursor-pointer">
                    <div className="w-full h-12 bg-muted rounded mb-2 flex items-center justify-center">
                      <i className="ri-layout-grid-line text-muted-foreground text-xl"></i>
                    </div>
                    <span className="text-sm">Grid</span>
                  </div>
                  
                  <div className="p-4 bg-card/80 border border-muted rounded-lg text-center cursor-pointer">
                    <div className="w-full h-12 bg-muted rounded mb-2 flex items-center justify-center">
                      <i className="ri-layout-masonry-line text-muted-foreground text-xl"></i>
                    </div>
                    <span className="text-sm">Compact</span>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Dark Mode</h3>
                  <p className="text-sm text-muted-foreground">Use dark theme for all screens</p>
                </div>
                <Switch checked={true} disabled />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Show Energy Usage</h3>
                  <p className="text-sm text-muted-foreground">Display energy consumption on device cards</p>
                </div>
                <Switch checked={true} />
              </div>
            </CardContent>
            <CardFooter className="flex justify-end border-t pt-4">
              <Button onClick={handleSaveSettings}>Save Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
          <CardDescription>
            Latest changes to your preferences and settings
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-4">
            <li className="flex gap-3">
              <div className="w-2 h-2 rounded-full bg-green-500 mt-2"></div>
              <div>
                <p className="text-sm">Comfort setting updated</p>
                <div className="flex gap-2 items-center">
                  <span className="text-xs text-muted-foreground">Today, 10:23 AM</span>
                  <Badge variant="outline" className="text-xs">Light Brightness: 65%</Badge>
                </div>
              </div>
            </li>
            
            <li className="flex gap-3">
              <div className="w-2 h-2 rounded-full bg-blue-500 mt-2"></div>
              <div>
                <p className="text-sm">Fan speed preference changed</p>
                <div className="flex gap-2 items-center">
                  <span className="text-xs text-muted-foreground">Yesterday, 8:17 PM</span>
                  <Badge variant="outline" className="text-xs">Fan Speed: Medium</Badge>
                </div>
              </div>
            </li>
            
            <li className="flex gap-3">
              <div className="w-2 h-2 rounded-full bg-yellow-500 mt-2"></div>
              <div>
                <p className="text-sm">Temperature range adjusted</p>
                <div className="flex gap-2 items-center">
                  <span className="text-xs text-muted-foreground">Aug 12, 2023</span>
                  <Badge variant="outline" className="text-xs">Min: 22°C</Badge>
                  <Badge variant="outline" className="text-xs">Max: 26°C</Badge>
                </div>
              </div>
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
