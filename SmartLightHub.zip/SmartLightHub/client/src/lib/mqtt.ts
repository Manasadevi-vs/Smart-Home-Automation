import { useEffect, useState } from 'react';

// This utility handles WebSocket connection to the server
// which relays MQTT messages to the client
export function useWebSocketConnection() {
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [connected, setConnected] = useState(false);
  const [mqttConnected, setMqttConnected] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);

  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    // Create WebSocket connection
    const ws = new WebSocket(wsUrl);
    
    ws.onopen = () => {
      console.log('WebSocket Connected');
      setConnected(true);
    };
    
    ws.onclose = () => {
      console.log('WebSocket Disconnected');
      setConnected(false);
      
      // Attempt to reconnect after 5 seconds
      setTimeout(() => {
        window.location.reload();
      }, 5000);
    };
    
    ws.onerror = (error) => {
      console.error('WebSocket Error', error);
    };
    
    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        // Update MQTT connection status
        if (data.type === 'mqtt_status') {
          setMqttConnected(data.connected);
        }
        
        // Handle MQTT messages
        if (data.type === 'mqtt_message') {
          setLastUpdate(new Date());
          // Handle specific message types
          const { topic, message } = data;
          // We'll handle these in the SmartHomeContext
        }
      } catch (error) {
        console.error('Error parsing WebSocket message', error);
      }
    };
    
    setSocket(ws);
    
    return () => {
      ws.close();
    };
  }, []);

  // Function to send messages to the WebSocket
  const sendMessage = (message: any) => {
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify(message));
      return true;
    }
    return false;
  };

  return {
    connected,
    mqttConnected, 
    lastUpdate,
    sendMessage
  };
}

// Control a device via MQTT
export function controlDevice(
  sendFunc: ((message: any) => boolean) | WebSocket | null, 
  topic: string, 
  payload: any
) {
  // If it's a function (from our useWebSocketConnection hook)
  if (typeof sendFunc === 'function') {
    return sendFunc({
      type: 'device_control',
      topic,
      message: payload
    });
  }
  
  // If it's a raw WebSocket
  if (sendFunc instanceof WebSocket && sendFunc.readyState === WebSocket.OPEN) {
    const message = {
      type: 'device_control',
      topic,
      message: payload
    };
    
    sendFunc.send(JSON.stringify(message));
    return true;
  }
  
  console.error('WebSocket not connected');
  return false;
}
