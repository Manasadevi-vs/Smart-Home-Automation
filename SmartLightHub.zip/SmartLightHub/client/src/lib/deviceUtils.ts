import { Device } from "@shared/schema";

// Light color options
export const lightColors = [
  { name: "Cool Blue", value: "cool", bg: "bg-blue-100", border: "border-blue-200" },
  { name: "Cool White", value: "cool-white", bg: "bg-blue-50", border: "border-blue-100" },
  { name: "Neutral", value: "neutral", bg: "bg-yellow-50", border: "border-yellow-100" },
  { name: "Warm White", value: "warm", bg: "bg-yellow-100", border: "border-yellow-200" },
  { name: "Warm Amber", value: "warm-amber", bg: "bg-orange-100", border: "border-orange-200" },
];

// Fan modes
export const fanModes = [
  { name: "Normal", value: "normal" },
  { name: "Natural", value: "natural" },
  { name: "Sleep", value: "sleep" },
];

// Get fan speed text from percentage
export function getFanSpeedText(speed: number): string {
  if (speed === 0) return "Off";
  if (speed <= 25) return "Low";
  if (speed <= 75) return "Medium";
  return "High";
}

// Calculate energy usage in kWh
export function calculateEnergyUsage(devices: Device[]): number {
  // This is a simple calculation - in a real system, this would be more complex
  // and would use actual power consumption data from the devices
  let totalWattHours = 0;
  
  for (const device of devices) {
    if (device.status) {
      // Lights - consumption based on brightness
      if (device.type === "light") {
        // Assume max light consumption is 10W
        const watts = 10 * (device.brightness / 100);
        totalWattHours += watts;
      }
      
      // Fans - consumption based on speed
      if (device.type === "fan") {
        // Assume max fan consumption is 30W
        const watts = 30 * (device.speed / 100);
        totalWattHours += watts;
      }
    }
  }
  
  // Convert to kWh
  return totalWattHours / 1000;
}

// Calculate comfort score based on active devices and settings
export function calculateComfortScore(
  devices: Device[], 
  temperature: number, 
  humidity: number
): { score: number, tempScore: number, lightScore: number } {
  // Temperature comfort calculation (ideal: 22-26°C, 30-60% humidity)
  let tempScore = 100;
  if (temperature < 18 || temperature > 30) {
    tempScore = 50;
  } else if (temperature < 20 || temperature > 28) {
    tempScore = 70;
  } else if (temperature < 22 || temperature > 26) {
    tempScore = 90;
  }
  
  if (humidity < 20 || humidity > 70) {
    tempScore -= 20;
  } else if (humidity < 30 || humidity > 60) {
    tempScore -= 10;
  }
  
  // Lighting comfort calculation
  const lights = devices.filter(d => d.type === "light");
  const activeLights = lights.filter(d => d.status);
  
  let lightScore = 0;
  if (activeLights.length > 0) {
    // Calculate average brightness of active lights
    const avgBrightness = activeLights.reduce((sum, light) => sum + light.brightness, 0) / activeLights.length;
    
    // Ideal brightness 40-70%
    if (avgBrightness < 20 || avgBrightness > 90) {
      lightScore = 70;
    } else if (avgBrightness < 40 || avgBrightness > 80) {
      lightScore = 85;
    } else {
      lightScore = 95;
    }
  } else {
    // No lights on - could be intentional, give average score
    lightScore = 80;
  }
  
  // Combine scores (60% temp/humidity, 40% lighting)
  const score = Math.round((tempScore * 0.6) + (lightScore * 0.4));
  
  return { 
    score, 
    tempScore, 
    lightScore
  };
}

// Get comfort level text from score
export function getComfortLevelText(score: number): {
  text: string;
  color: string;
} {
  if (score >= 90) {
    return { text: "Excellent", color: "text-green-500" };
  }
  if (score >= 75) {
    return { text: "Good", color: "text-blue-500" };
  }
  if (score >= 60) {
    return { text: "Average", color: "text-yellow-500" };
  }
  return { text: "Poor", color: "text-red-500" };
}
