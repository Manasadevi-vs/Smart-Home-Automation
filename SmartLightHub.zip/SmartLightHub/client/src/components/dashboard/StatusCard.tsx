import { cn } from "@/lib/utils";

interface StatusCardProps {
  title: string;
  icon: string;
  iconColor: string;
  value: string;
  subtitle: string;
  badge?: {
    text: string;
    color: string;
  };
  children?: React.ReactNode;
}

export function StatusCard({
  title,
  icon,
  iconColor,
  value,
  subtitle,
  badge,
  children,
}: StatusCardProps) {
  return (
    <div className="bg-card p-4 rounded-xl shadow-md device-card">
      <div className="flex justify-between items-center">
        <div className="flex items-center">
          <i className={cn(icon, iconColor, "text-lg mr-2")}></i>
          <span className="text-sm">{title}</span>
        </div>
        {badge && (
          <div className={cn("text-xs py-1 px-2 rounded-full", 
            `bg-${badge.color} bg-opacity-20 text-${badge.color}`)}>
            {badge.text}
          </div>
        )}
      </div>
      <div className="mt-3 flex items-baseline">
        <span className="text-3xl font-bold">{value}</span>
        <span className="text-muted-foreground text-sm ml-2">{subtitle}</span>
      </div>
      {children}
    </div>
  );
}

export function TemperatureCard({
  temperature,
  humidity,
}: {
  temperature: number;
  humidity: number;
}) {
  return (
    <StatusCard
      title="Temperature"
      icon="ri-temp-hot-line"
      iconColor="text-accent"
      value={`${temperature}°C`}
      subtitle={`/ ${humidity}% Humidity`}
      badge={{ text: "Optimal", color: "accent" }}
    >
      <div className="mt-3 h-2 bg-muted rounded-full overflow-hidden">
        <div 
          className="h-full bg-accent" 
          style={{ width: `${((temperature - 18) / (28 - 18)) * 100}%` }}
        ></div>
      </div>
      <div className="mt-2 flex justify-between text-xs text-muted-foreground">
        <span>18°C</span>
        <span>28°C</span>
      </div>
    </StatusCard>
  );
}

export function EnergyCard({
  usage,
  weeklyGoal,
  currentWeekUsage,
}: {
  usage: number;
  weeklyGoal: number;
  currentWeekUsage: number;
}) {
  const percentage = Math.min(100, Math.round((currentWeekUsage / weeklyGoal) * 100));
  const dasharray = 100;
  const dashoffset = dasharray - (percentage / 100) * dasharray;

  return (
    <StatusCard
      title="Energy Usage"
      icon="ri-flashlight-line"
      iconColor="text-secondary"
      value={`${usage.toFixed(1)}kWh`}
      subtitle="/ Last 24h"
      badge={{ text: "-12%", color: "secondary" }}
    >
      <div className="flex justify-between items-center mt-3">
        <div className="w-12 h-12 relative">
          <svg className="w-12 h-12" viewBox="0 0 36 36">
            <circle cx="18" cy="18" r="16" fill="none" stroke="hsl(var(--muted))" strokeWidth="2"></circle>
            <circle 
              className="progress-ring-circle" 
              cx="18" 
              cy="18" 
              r="16" 
              fill="none" 
              stroke="hsl(var(--secondary))" 
              strokeWidth="2" 
              strokeDasharray={dasharray} 
              strokeDashoffset={dashoffset}
            ></circle>
          </svg>
          <span className="absolute inset-0 flex items-center justify-center text-xs">{percentage}%</span>
        </div>
        <div className="text-xs text-muted-foreground ml-3">
          <div>Weekly goal: {weeklyGoal}kWh</div>
          <div>Current: {currentWeekUsage.toFixed(1)}kWh</div>
        </div>
      </div>
    </StatusCard>
  );
}

export function DevicesCard() {
  // Using mock data for now since we have context issues
  const mockDevices = [
    { id: 1, type: "light", status: true },
    { id: 2, type: "light", status: false },
    { id: 3, type: "fan", status: true },
    { id: 4, type: "fan", status: false },
    { id: 5, type: "light", status: true },
  ];
  
  const totalDevices = mockDevices.length;
  const activeDevices = mockDevices.filter(d => d.status);
  const activeLights = activeDevices.filter(d => d.type === "light");
  const activeFans = activeDevices.filter(d => d.type === "fan");
  const lightCount = activeLights.length;
  const fanCount = activeFans.length;

  return (
    <StatusCard
      title="Active Devices"
      icon="ri-device-line"
      iconColor="text-primary"
      value={activeDevices.length.toString()}
      subtitle={`/ ${totalDevices}`}
      badge={{ text: `${Math.round((activeDevices.length/Math.max(totalDevices, 1))*100)}% Active`, color: "primary" }}
    >
      <div className="mt-3 space-y-3">
        <div className="flex justify-between items-center bg-accent/5 p-2 rounded-lg">
          <div className="flex gap-2 items-center">
            <div className={`w-6 h-6 flex items-center justify-center ${lightCount > 0 ? 'text-accent' : 'text-muted-foreground'}`}>
              <i className="ri-lightbulb-flash-line"></i>
            </div>
            <span className="text-sm font-medium">Lights</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="text-xs px-2 py-0.5 bg-accent/10 text-accent rounded-full">
              {lightCount} active
            </div>
          </div>
        </div>
        
        <div className="flex justify-between items-center bg-primary/5 p-2 rounded-lg">
          <div className="flex gap-2 items-center">
            <div className={`w-6 h-6 flex items-center justify-center ${fanCount > 0 ? 'text-primary' : 'text-muted-foreground'}`}>
              <i className="ri-fan-line"></i>
            </div>
            <span className="text-sm font-medium">Fans</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="text-xs px-2 py-0.5 bg-primary/10 text-primary rounded-full">
              {fanCount} active
            </div>
          </div>
        </div>
        
        <div className="flex justify-between items-center bg-muted/10 p-2 rounded-lg">
          <div className="flex gap-2 items-center">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-door-lock-line text-muted-foreground"></i>
            </div>
            <span className="text-sm font-medium">Other</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="text-xs px-2 py-0.5 bg-muted/20 text-muted-foreground rounded-full">
              All inactive
            </div>
          </div>
        </div>
      </div>
    </StatusCard>
  );
}

export function ComfortCard({
  score,
  tempScore,
  lightScore,
}: {
  score: number;
  tempScore: number;
  lightScore: number;
}) {
  let comfortLevel = "Excellent";
  let comfortColor = "red-500";
  
  if (score < 60) {
    comfortLevel = "Poor";
  } else if (score < 75) {
    comfortLevel = "Average";
    comfortColor = "yellow-500";
  } else if (score < 90) {
    comfortLevel = "Good";
    comfortColor = "blue-500";
  }

  return (
    <StatusCard
      title="Comfort Score"
      icon="ri-heart-line"
      iconColor="text-red-500"
      value={score.toString()}
      subtitle="/ 100"
      badge={{ text: comfortLevel, color: "red-500" }}
    >
      <div className="mt-3">
        <div className="flex justify-between mb-1">
          <span className="text-xs text-muted-foreground">Temperature</span>
          <span className="text-xs text-green-500">
            {tempScore >= 90 ? "Perfect" : tempScore >= 75 ? "Good" : "Average"}
          </span>
        </div>
        <div className="h-1.5 bg-muted rounded-full overflow-hidden">
          <div 
            className="h-full bg-green-500" 
            style={{ width: `${tempScore}%` }}
          ></div>
        </div>
      </div>
      <div className="mt-2">
        <div className="flex justify-between mb-1">
          <span className="text-xs text-muted-foreground">Lighting</span>
          <span className="text-xs text-blue-500">
            {lightScore >= 90 ? "Perfect" : lightScore >= 75 ? "Good" : "Average"}
          </span>
        </div>
        <div className="h-1.5 bg-muted rounded-full overflow-hidden">
          <div 
            className="h-full bg-blue-500" 
            style={{ width: `${lightScore}%` }}
          ></div>
        </div>
      </div>
    </StatusCard>
  );
}
