import { useState } from "react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  ResponsiveContainer, 
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  Sector
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

// Chart data types
interface EnergyData {
  time: string;
  value: number;
  label?: string;
}

interface DeviceBreakdownData {
  name: string;
  value: number;
  color: string;
  percentage: number;
}

interface EnergyChartProps {
  data: EnergyData[];
  deviceBreakdown: DeviceBreakdownData[];
  period: "day" | "week" | "month";
  onPeriodChange: (period: "day" | "week" | "month") => void;
}

export function EnergyChart({ 
  data, 
  deviceBreakdown, 
  period, 
  onPeriodChange 
}: EnergyChartProps) {
  const [activeIndex, setActiveIndex] = useState(0);

  const onPieEnter = (_: any, index: number) => {
    setActiveIndex(index);
  };

  // Custom tooltip for bar chart
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-card text-card-foreground p-2 border border-border rounded-md shadow-md">
          <p className="font-medium">{`${label}`}</p>
          <p className="text-sm text-muted-foreground">{`Energy: ${payload[0].value.toFixed(2)} kW`}</p>
        </div>
      );
    }
    return null;
  };

  // Active shape for pie chart
  const renderActiveShape = (props: any) => {
    const { cx, cy, innerRadius, outerRadius, startAngle, endAngle, fill, payload, percent } = props;
  
    return (
      <g>
        <text x={cx} y={cy} dy={-15} textAnchor="middle" fill="hsl(var(--foreground))">
          {payload.name}
        </text>
        <text x={cx} y={cy} dy={15} textAnchor="middle" fill="hsl(var(--foreground))">
          {`${(percent * 100).toFixed(0)}%`}
        </text>
        <Sector
          cx={cx}
          cy={cy}
          innerRadius={innerRadius}
          outerRadius={outerRadius + 5}
          startAngle={startAngle}
          endAngle={endAngle}
          fill={fill}
        />
      </g>
    );
  };

  return (
    <Card className="bg-card shadow-md">
      <CardHeader className="flex flex-row items-center justify-between p-5">
        <CardTitle className="text-lg font-semibold">Energy Usage</CardTitle>
        <div className="flex space-x-2">
          <Button 
            variant={period === "day" ? "default" : "outline"} 
            size="sm"
            onClick={() => onPeriodChange("day")}
            className="px-3 py-1 text-xs"
          >
            Day
          </Button>
          <Button 
            variant={period === "week" ? "default" : "outline"} 
            size="sm"
            onClick={() => onPeriodChange("week")}
            className="px-3 py-1 text-xs"
          >
            Week
          </Button>
          <Button 
            variant={period === "month" ? "default" : "outline"} 
            size="sm"
            onClick={() => onPeriodChange("month")}
            className="px-3 py-1 text-xs"
          >
            Month
          </Button>
        </div>
      </CardHeader>

      <CardContent className="p-0">
        {/* Energy Usage Chart */}
        <div className="h-64 relative">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={data}
              margin={{ top: 10, right: 30, left: 40, bottom: 20 }}
            >
              <XAxis 
                dataKey="time" 
                tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                tickLine={false}
                axisLine={false}
              />
              <YAxis 
                tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                tickLine={false}
                axisLine={false}
                tickFormatter={(value) => `${value} kW`}
              />
              <Tooltip content={<CustomTooltip />} />
              <Bar 
                dataKey="value" 
                fill="hsl(var(--primary-dark, var(--primary)))" 
                radius={[4, 4, 0, 0]}
                animationDuration={500}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Device Breakdown */}
        <div className="mt-4 p-5">
          <h4 className="text-sm font-medium mb-3">Device Breakdown</h4>
          
          <div className="flex flex-col md:flex-row">
            {/* Pie Chart */}
            <div className="w-full md:w-1/3 h-40 md:h-auto">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    activeIndex={activeIndex}
                    activeShape={renderActiveShape}
                    data={deviceBreakdown}
                    cx="50%"
                    cy="50%"
                    innerRadius={30}
                    outerRadius={50}
                    dataKey="value"
                    onMouseEnter={onPieEnter}
                  >
                    {deviceBreakdown.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>
            
            {/* Bar representations */}
            <div className="w-full md:w-2/3 space-y-3">
              {deviceBreakdown.map((device, index) => (
                <div key={index} className="flex items-center">
                  <div 
                    className="w-1.5 h-8 rounded-full mr-3" 
                    style={{ backgroundColor: device.color }}
                  ></div>
                  <div className="flex-1">
                    <div className="flex justify-between text-sm">
                      <span>{device.name}</span>
                      <span className="font-medium">
                        {device.value.toFixed(1)} kWh ({device.percentage}%)
                      </span>
                    </div>
                    <div className="h-1.5 bg-muted rounded-full overflow-hidden mt-1">
                      <div 
                        className="h-full" 
                        style={{ 
                          width: `${device.percentage}%`,
                          backgroundColor: device.color
                        }}
                      ></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
