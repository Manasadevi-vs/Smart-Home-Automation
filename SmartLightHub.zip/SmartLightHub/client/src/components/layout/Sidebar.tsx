import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useState, useEffect } from "react";

const navigationItems = [
  { name: "Dashboard", path: "/", icon: "ri-dashboard-line" },
  { name: "Lighting", path: "/lighting", icon: "ri-lightbulb-line" },
  { name: "Fans & Climate", path: "/fans", icon: "ri-windy-line" },
  { name: "Energy Usage", path: "/energy", icon: "ri-bar-chart-line" },
  { name: "Scheduling", path: "/scheduling", icon: "ri-timer-line" },
  { name: "Gamification", path: "/gamification", icon: "ri-trophy-line" },
  { name: "User Preferences", path: "/preferences", icon: "ri-user-settings-line" },
];

export default function Sidebar() {
  const [location] = useLocation();
  const [userName, setUserName] = useState("Alex Johnson");
  const [userRole, setUserRole] = useState("Admin");
  
  // Load user from API directly to avoid context issues
  useEffect(() => {
    const loadUser = async () => {
      try {
        const response = await fetch('/api/users');
        const users = await response.json();
        if (users && users.length > 0) {
          setUserName(users[0].name || "Alex Johnson");
          setUserRole(users[0].role || "Admin");
        }
      } catch (error) {
        console.error('Failed to load user:', error);
      }
    };
    
    loadUser();
  }, []);

  return (
    <aside className="hidden md:flex flex-col w-64 bg-card border-r border-border h-full p-4">
      {/* Logo */}
      <div className="flex items-center pl-2 mb-8">
        <i className="ri-home-smile-fill text-3xl text-primary mr-2"></i>
        <h1 className="text-xl font-bold">SmartHome</h1>
      </div>

      {/* Navigation */}
      <nav className="mb-10">
        <ul className="space-y-2">
          {navigationItems.map((item) => (
            <li key={item.path}>
              <Link 
                href={item.path}
                className={cn(
                  "flex items-center px-4 py-3 rounded-lg",
                  location === item.path 
                    ? "bg-primary bg-opacity-20 text-primary" 
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                )}
              >
                <i className={cn(item.icon, "mr-3")}></i>
                <span>{item.name}</span>
              </Link>
            </li>
          ))}
        </ul>
      </nav>

      {/* User profile */}
      <div className="mt-auto">
        <div className="flex items-center p-4 bg-muted rounded-lg">
          <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary">
            {userName.charAt(0) || 'A'}
          </div>
          <div className="ml-3">
            <p className="text-sm font-medium">{userName}</p>
            <p className="text-xs text-muted-foreground">{userRole}</p>
          </div>
          <button className="ml-auto text-muted-foreground hover:text-foreground">
            <i className="ri-settings-3-line"></i>
          </button>
        </div>
      </div>
    </aside>
  );
}
