import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

const navigationItems = [
  { name: "Dashboard", path: "/", icon: "ri-dashboard-line" },
  { name: "Lighting", path: "/lighting", icon: "ri-lightbulb-line" },
  { name: "Fans & Climate", path: "/fans", icon: "ri-windy-line" },
  { name: "Energy Usage", path: "/energy", icon: "ri-bar-chart-line" },
  { name: "Scheduling", path: "/scheduling", icon: "ri-timer-line" },
  { name: "Gamification", path: "/gamification", icon: "ri-trophy-line" },
  { name: "User Preferences", path: "/preferences", icon: "ri-user-settings-line" },
];

export default function MobileNavBar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [location] = useLocation();
  const [user, setUser] = useState<{name: string; role: string}>({name: "Alex", role: "Admin"});
  
  // Load user directly from API instead of context
  useEffect(() => {
    const loadUser = async () => {
      try {
        const response = await fetch('/api/users');
        const users = await response.json();
        if (users && users.length > 0) {
          setUser({
            name: users[0].name || "Alex",
            role: users[0].role || "Admin"
          });
        }
      } catch (error) {
        console.error('Failed to load user:', error);
      }
    };
    
    loadUser();
  }, []);

  return (
    <>
      {/* Mobile header */}
      <div className="md:hidden fixed top-0 left-0 right-0 z-30 bg-card border-b border-border px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <i className="ri-home-smile-fill text-2xl text-primary mr-2"></i>
            <h1 className="text-lg font-bold">SmartHome</h1>
          </div>
          <button 
            className="text-xl text-muted-foreground"
            onClick={() => setMenuOpen(true)}
          >
            <i className="ri-menu-line"></i>
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <div className={cn(
        "fixed inset-0 z-40 bg-background bg-opacity-95 transition-opacity",
        menuOpen ? "block" : "hidden"
      )}>
        <div className="flex flex-col h-full px-4 pt-16 pb-4">
          <button 
            className="absolute top-4 right-4 text-xl"
            onClick={() => setMenuOpen(false)}
          >
            <i className="ri-close-line"></i>
          </button>
          <nav className="mb-auto">
            <ul className="space-y-3">
              {navigationItems.map((item) => (
                <li key={item.path}>
                  <Link 
                    href={item.path}
                    className={cn(
                      "flex items-center px-4 py-3 rounded-lg",
                      location === item.path 
                        ? "bg-primary bg-opacity-20 text-primary" 
                        : "text-muted-foreground hover:bg-muted hover:text-foreground"
                    )}
                    onClick={() => setMenuOpen(false)}
                  >
                    <i className={cn(item.icon, "mr-3")}></i>
                    <span>{item.name}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          {/* User profile (mobile) */}
          <div className="mt-auto">
            <div className="flex items-center p-4 bg-muted rounded-lg">
              <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary">
                {user?.name?.charAt(0) || 'A'}
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium">{user?.name || "Alex Johnson"}</p>
                <p className="text-xs text-muted-foreground">{user?.role || "Admin"}</p>
              </div>
              <button className="ml-auto text-muted-foreground hover:text-foreground">
                <i className="ri-settings-3-line"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
