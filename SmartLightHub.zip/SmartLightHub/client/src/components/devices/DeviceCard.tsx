import { useState } from "react";
import { Device } from "@shared/schema";
import { Switch } from "@/components/ui/switch";
import LightControls from "./LightControls";
import FanControls from "./FanControls";
import AnimatedDeviceIcon from "./AnimatedDeviceIcon";

interface DeviceCardProps {
  device: Device;
}

export default function DeviceCard({ device }: DeviceCardProps) {
  const [status, setStatus] = useState(device.status || false);
  const [isHovered, setIsHovered] = useState(false);

  const handleToggleStatus = async (newStatus: boolean) => {
    setStatus(newStatus);
    
    // Update device in API directly
    try {
      await fetch(`/api/devices/${device.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status: newStatus }),
      });
    } catch (error) {
      console.error('Failed to update device status:', error);
    }
  };

  // Create a device object with updated status for the AnimatedDeviceIcon
  const deviceWithCurrentStatus = {
    ...device,
    status
  };

  return (
    <div 
      className="p-4 bg-card/80 rounded-lg device-card transition-all duration-200 hover:shadow-md"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="flex justify-between items-center mb-3">
        <div className="flex items-center">
          <div className={`${isHovered && status ? "animate-bounce-gentle" : ""}`}>
            <AnimatedDeviceIcon device={deviceWithCurrentStatus} size="md" />
          </div>
          <div className="ml-3">
            <h4 className="font-medium">{device.name}</h4>
            <p className="text-xs text-muted-foreground">
              {device.type === "light" 
                ? `${status ? device.brightness + "%" : "Off"}` 
                : `${status ? (device.speed || 0) + "%" : "Off"}`}
            </p>
          </div>
        </div>
        <Switch checked={status} onCheckedChange={handleToggleStatus} />
      </div>
      
      <div className={status ? "" : "opacity-50 pointer-events-none"}>
        {device.type === "light" ? (
          <LightControls 
            device={device}
            disabled={!status}
          />
        ) : (
          <FanControls 
            device={device}
            disabled={!status}
          />
        )}
      </div>
    </div>
  );
}
