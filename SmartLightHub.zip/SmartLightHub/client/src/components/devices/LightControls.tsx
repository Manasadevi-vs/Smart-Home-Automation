import { useState } from "react";
import { Device } from "@shared/schema";
import { cn } from "@/lib/utils";
import { lightColors } from "@/lib/deviceUtils";

interface LightControlsProps {
  device: Device;
  disabled?: boolean;
}

export default function LightControls({ device, disabled = false }: LightControlsProps) {
  const [brightness, setBrightness] = useState(device.brightness || 0);
  const [color, setColor] = useState(device.color || "warm");

  const updateDeviceProperty = async (updates: Partial<Device>) => {
    try {
      await fetch(`/api/devices/${device.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updates),
      });
    } catch (error) {
      console.error('Failed to update device:', error);
    }
  };

  const handleBrightnessChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newBrightness = parseInt(e.target.value);
    setBrightness(newBrightness);
    updateDeviceProperty({ brightness: newBrightness });
  };

  const handleColorChange = (newColor: string) => {
    setColor(newColor);
    updateDeviceProperty({ color: newColor });
  };

  return (
    <>
      <div className="mb-3">
        <div className="flex justify-between text-sm mb-1">
          <span>Brightness</span>
          <span>{brightness}%</span>
        </div>
        <input 
          type="range" 
          min="0" 
          max="100" 
          value={brightness} 
          onChange={handleBrightnessChange}
          className="w-full" 
          disabled={disabled}
        />
      </div>
      
      <div>
        <div className="flex justify-between text-sm mb-1">
          <span>Color Temperature</span>
          <span className="capitalize">{color}</span>
        </div>
        <div className="flex space-x-2">
          {lightColors.map((lightColor) => (
            <button 
              key={lightColor.value}
              className={cn(
                "w-8 h-8 rounded-full", 
                lightColor.bg,
                "border-2",
                color === lightColor.value ? "border-primary" : "border-transparent"
              )}
              onClick={() => handleColorChange(lightColor.value)}
              disabled={disabled}
              aria-label={`Set light to ${lightColor.name}`}
            />
          ))}
        </div>
      </div>
    </>
  );
}
