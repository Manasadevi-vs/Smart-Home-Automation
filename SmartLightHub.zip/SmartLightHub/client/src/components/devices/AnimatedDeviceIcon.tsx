import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { Device } from "@shared/schema";
import { getFanSpeedText } from "@/lib/deviceUtils";

interface AnimatedDeviceIconProps {
  device: Device;
  size?: "sm" | "md" | "lg";
  showLabel?: boolean;
  className?: string;
}

export default function AnimatedDeviceIcon({ 
  device, 
  size = "md", 
  showLabel = false,
  className
}: AnimatedDeviceIconProps) {
  const [isAnimating, setIsAnimating] = useState(false);
  
  // Start animation after component mounts
  useEffect(() => {
    if (device.status) {
      setIsAnimating(true);
    } else {
      setIsAnimating(false);
    }
  }, [device.status]);

  const sizeClasses = {
    sm: "w-6 h-6 text-sm",
    md: "w-10 h-10 text-lg",
    lg: "w-14 h-14 text-2xl"
  };

  const containerClasses = cn(
    sizeClasses[size],
    "rounded-full flex items-center justify-center relative",
    device.type === "light" 
      ? "bg-accent/20" 
      : "bg-primary/20",
    className
  );

  const getAnimationClass = () => {
    if (!isAnimating) return "";
    
    if (device.type === "light") {
      const brightness = device.brightness || 0;
      
      if (brightness < 30) {
        return "animate-pulse-glow";
      } else if (brightness < 70) {
        return "animate-light-flicker";
      } else {
        return "animate-pulse-glow animate-light-flicker";
      }
    } else if (device.type === "fan") {
      const speed = device.speed || 0;
      
      if (speed <= 25) {
        return "animate-fan-spin-slow";
      } else if (speed <= 75) {
        return "animate-fan-spin-medium";
      } else {
        return "animate-fan-spin-fast";
      }
    }
    
    return "";
  };

  const getDeviceIcon = () => {
    if (device.type === "light") {
      return device.status ? "ri-lightbulb-fill" : "ri-lightbulb-line";
    } else if (device.type === "fan") {
      return "ri-loader-4-line"; // Changed from windy-line for better spinning animation
    }
    return "ri-device-line";
  };

  const getTextLabel = () => {
    if (!device.status) return "Off";
    
    if (device.type === "light") {
      return `${device.brightness}%`;
    } else if (device.type === "fan") {
      return getFanSpeedText(device.speed || 0);
    }
    
    return "On";
  };

  const getBgEffect = () => {
    if (!device.status) return null;
    
    if (device.type === "light") {
      const brightness = device.brightness || 0;
      const opacity = Math.min(brightness / 200 + 0.1, 0.5);
      
      let color = "rgba(252, 211, 77, VAR)"; // Default warm color
      
      if (device.color) {
        if (device.color.includes("cool")) {
          color = "rgba(191, 219, 254, VAR)"; // Cool blue
        } else if (device.color.includes("warm-amber")) {
          color = "rgba(253, 186, 116, VAR)"; // Warm amber
        }
      }
      
      return (
        <div 
          className="absolute w-full h-full rounded-full animate-pulse-glow"
          style={{
            boxShadow: `0 0 15px 2px ${color.replace("VAR", opacity.toString())}`,
            zIndex: -1
          }}
        />
      );
    }
    
    return null;
  };

  return (
    <div className="flex flex-col items-center">
      <div className={containerClasses}>
        {getBgEffect()}
        <i className={cn(
          getDeviceIcon(),
          device.type === "light" ? "text-accent" : "text-primary",
          getAnimationClass()
        )}></i>
      </div>
      {showLabel && (
        <span className="text-xs mt-1 font-medium">
          {getTextLabel()}
        </span>
      )}
    </div>
  );
}