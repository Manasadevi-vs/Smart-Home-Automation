import { useState } from "react";
import { Device } from "@shared/schema";
import { cn } from "@/lib/utils";
import { getFanSpeedText, fanModes } from "@/lib/deviceUtils";

interface FanControlsProps {
  device: Device;
  disabled?: boolean;
}

export default function FanControls({ device, disabled = false }: FanControlsProps) {
  const [speed, setSpeed] = useState(device.speed || 0);
  const [mode, setMode] = useState(device.mode || "normal");

  const updateDeviceProperty = async (updates: Partial<Device>) => {
    try {
      await fetch(`/api/devices/${device.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updates),
      });
    } catch (error) {
      console.error('Failed to update device:', error);
    }
  };

  const handleSpeedChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newSpeed = parseInt(e.target.value);
    setSpeed(newSpeed);
    updateDeviceProperty({ speed: newSpeed });
  };

  const handleModeChange = (newMode: string) => {
    setMode(newMode);
    updateDeviceProperty({ mode: newMode });
  };

  return (
    <>
      <div className="mb-3">
        <div className="flex justify-between text-sm mb-1">
          <span>Speed</span>
          <span>{getFanSpeedText(speed)} ({speed}%)</span>
        </div>
        <input 
          type="range" 
          min="0" 
          max="100" 
          value={speed} 
          onChange={handleSpeedChange}
          className="w-full" 
          disabled={disabled}
        />
      </div>
      
      <div>
        <div className="flex justify-between text-sm mb-1">
          <span>Mode</span>
          <span className="capitalize">{mode}</span>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {fanModes.map((fanMode) => (
            <button 
              key={fanMode.value}
              className={cn(
                "py-1.5 rounded text-xs",
                mode === fanMode.value 
                  ? "bg-primary text-white" 
                  : "bg-muted text-muted-foreground hover:bg-muted/80"
              )}
              onClick={() => handleModeChange(fanMode.value)}
              disabled={disabled}
            >
              {fanMode.name}
            </button>
          ))}
        </div>
      </div>
    </>
  );
}
