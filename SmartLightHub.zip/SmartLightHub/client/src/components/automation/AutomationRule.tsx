import React, { useState, useEffect } from "react";
import { Rule, Device } from "@shared/schema";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";

interface AutomationRuleProps {
  rule: Rule;
}

export default function AutomationRule({ rule }: AutomationRuleProps) {
  const [devices, setDevices] = useState<Device[]>([]);

  // Fetch devices from API
  useEffect(() => {
    const fetchDevices = async () => {
      try {
        const response = await fetch('/api/devices');
        const data = await response.json();
        setDevices(data);
      } catch (error) {
        console.error('Error fetching devices:', error);
      }
    };
    
    fetchDevices();
  }, []);

  const handleToggleActive = async (isActive: boolean) => {
    try {
      await fetch(`/api/rules/${rule.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ isActive }),
      });
    } catch (error) {
      console.error('Failed to update rule:', error);
    }
  };

  const getTriggerDescription = () => {
    if (rule.trigger === "time") {
      const triggerData = rule.triggerData as { time: string, days: number[] };
      if (triggerData.time === "sunset") {
        return "Activates at sunset every day";
      }
      
      const days = triggerData.days.length === 7 
        ? "every day" 
        : triggerData.days.includes(0) && triggerData.days.includes(6) && triggerData.days.length === 2
          ? "on weekends"
          : "on weekdays";
      
      return `Activates at ${triggerData.time} ${days}`;
    }
    
    if (rule.trigger === "manual") {
      return "Manual activation";
    }
    
    return rule.description || "";
  };

  const getDeviceById = (id: number): Device | undefined => {
    return devices.find(device => device.id === id);
  };

  const renderAction = (action: any) => {
    const device = getDeviceById(action.deviceId);
    if (!device) return null;

    let statusText = "";
    let iconClass = "";
    
    if (device.type === "light") {
      iconClass = "ri-lightbulb-line text-accent";
      if (action.status === false) {
        statusText = "Off";
      } else if (action.brightness !== undefined) {
        statusText = `${action.brightness}%`;
      } else {
        statusText = "On";
      }
      
      if (action.color) {
        statusText += ` (${action.color})`;
      }
    } else if (device.type === "fan") {
      iconClass = "ri-windy-line text-primary";
      if (action.status === false) {
        statusText = "Off";
      } else if (action.speed !== undefined) {
        statusText = action.speed > 75 
          ? "High" 
          : action.speed > 30 
            ? "Medium" 
            : "Low";
      } else {
        statusText = "On";
      }
      
      if (action.mode) {
        statusText += ` (${action.mode})`;
      }
    }

    return (
      <span key={device.id} className="text-xs bg-muted px-2 py-1 rounded-full flex items-center">
        <i className={cn(iconClass, "mr-1")}></i> {device.name}: {statusText}
      </span>
    );
  };

  // Function to render actions safely
  const renderActions = () => {
    if (!rule.actions || !Array.isArray(rule.actions)) {
      return null;
    }
    
    return rule.actions.map((action: any, index: number) => {
      const actionElement = renderAction(action);
      return actionElement ? <div key={index}>{actionElement}</div> : null;
    });
  };

  return (
    <div className="p-3 bg-card/80 rounded-lg border border-muted">
      <div className="flex justify-between items-start">
        <div>
          <h4 className="font-medium">{rule.name}</h4>
          <p className="text-xs text-muted-foreground mt-1">{getTriggerDescription()}</p>
        </div>
        <Switch checked={rule.isActive === true} onCheckedChange={handleToggleActive} />
      </div>
      <div className="flex flex-wrap mt-3 gap-2">
        {renderActions()}
      </div>
    </div>
  );
}
