import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";

export function AIAssistant() {
  const [command, setCommand] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [energyTips, setEnergyTips] = useState<string[]>([]);
  const [isLoadingTips, setIsLoadingTips] = useState(false);
  const [activeTab, setActiveTab] = useState("command");
  const [commandResult, setCommandResult] = useState<{
    success: boolean;
    message: string;
    actions?: Array<{ deviceId: number; deviceName: string; action: string; parameters?: any }>;
  } | null>(null);
  const { toast } = useToast();

  // Fetch energy saving tips
  useEffect(() => {
    const fetchEnergyTips = async () => {
      setIsLoadingTips(true);
      try {
        const response = await fetch("/api/ai/energy-tips?userId=1");
        const data = await response.json();
        if (data.tips && Array.isArray(data.tips)) {
          setEnergyTips(data.tips);
        } else if (data.error && data.error.includes("quota")) {
          // Handle OpenAI quota error specifically
          console.error("OpenAI API quota exceeded:", data.error);
          setEnergyTips([
            "OpenAI API quota limit reached. Here are some general energy-saving tips instead:",
            "Consider turning off lights in unoccupied rooms to reduce electricity usage.",
            "Adjust the brightness of your lighting based on the time of day to optimize energy consumption.",
            "Schedule your devices to turn off automatically during periods of inactivity."
          ]);
        }
      } catch (error) {
        console.error("Error fetching energy tips:", error);
        toast({
          title: "Error",
          description: "Failed to load AI energy recommendations.",
          variant: "destructive"
        });
        // Provide fallback tips
        setEnergyTips([
          "Unable to connect to AI service. Here are some general energy-saving tips:",
          "Consider turning off lights in unoccupied rooms to reduce electricity usage.",
          "Adjust the brightness of your lighting based on the time of day to optimize energy consumption.",
          "Schedule your devices to turn off automatically during periods of inactivity."
        ]);
      } finally {
        setIsLoadingTips(false);
      }
    };

    fetchEnergyTips();
  }, [toast]);

  // Process voice commands
  const handleCommandSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!command.trim()) return;

    setIsLoading(true);
    try {
      const response = await fetch("/api/ai/command", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ command })
      });

      const result = await response.json();
      
      // Handle API quota errors
      if (result.error && result.error.includes("quota")) {
        setCommandResult({
          success: false,
          message: "The AI service is currently unavailable due to API quota limitations. Please try the direct device controls instead."
        });
        
        toast({
          title: "API Quota Exceeded",
          description: "AI service unavailable. Please use direct device controls.",
          variant: "destructive"
        });
      } else {
        setCommandResult(result);

        // Display toast notification
        if (result.success) {
          toast({
            title: "Command processed",
            description: result.message,
            variant: "default"
          });
        } else {
          toast({
            title: "Command failed",
            description: result.message,
            variant: "destructive"
          });
        }
      }
    } catch (error) {
      console.error("Error processing command:", error);
      toast({
        title: "Error",
        description: "Failed to process your command. Please try again.",
        variant: "destructive"
      });
      
      // Set a fallback error message
      setCommandResult({
        success: false,
        message: "An error occurred while connecting to the AI service. Please try again or use the device controls directly."
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="col-span-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <i className="ri-brain-line text-primary"></i> AI Assistant
        </CardTitle>
        <CardDescription>
          Get personalized recommendations and control your smart home with natural language
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs
          value={activeTab}
          onValueChange={setActiveTab}
          className="w-full"
        >
          <TabsList className="mb-4">
            <TabsTrigger value="command">Voice Commands</TabsTrigger>
            <TabsTrigger value="tips">Energy Tips</TabsTrigger>
          </TabsList>

          <TabsContent value="command">
            <div className="space-y-4">
              <form onSubmit={handleCommandSubmit} className="flex gap-2">
                <Input
                  placeholder="Try 'Turn off all lights' or 'Set living room brightness to 70%'"
                  value={command}
                  onChange={(e) => setCommand(e.target.value)}
                  disabled={isLoading}
                  className="flex-1"
                />
                <Button type="submit" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <i className="ri-loader-4-line animate-spin mr-1"></i> Processing
                    </>
                  ) : (
                    <>
                      <i className="ri-send-plane-fill mr-1"></i> Send
                    </>
                  )}
                </Button>
              </form>

              {commandResult && (
                <div className={`p-4 rounded-lg ${commandResult.success ? 'bg-primary/10' : 'bg-destructive/10'}`}>
                  <p className="font-medium">{commandResult.message}</p>
                  
                  {commandResult.success && commandResult.actions && commandResult.actions.length > 0 && (
                    <div className="mt-2 space-y-1 text-sm">
                      <p className="font-medium">Actions performed:</p>
                      <ul className="list-disc pl-5">
                        {commandResult.actions.map((action, idx) => (
                          <li key={idx}>
                            {action.deviceName}: {action.action.replace(/_/g, ' ')}
                            {action.parameters && Object.entries(action.parameters).map(([key, value]) => (
                              ` ${key} to ${value}`
                            ))}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}

              <div className="mt-4">
                <h4 className="text-sm font-medium mb-2">Example commands:</h4>
                <div className="flex flex-wrap gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCommand("Turn off all the lights")}
                  >
                    Turn off all lights
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCommand("Set bedroom fan to medium speed")}
                  >
                    Set bedroom fan speed
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCommand("Turn on living room lights at 70% brightness")}
                  >
                    Living room lights at 70%
                  </Button>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="tips">
            {isLoadingTips ? (
              <div className="flex justify-center items-center py-8">
                <i className="ri-loader-4-line animate-spin text-2xl text-primary mr-2"></i>
                <span>Loading recommendations...</span>
              </div>
            ) : (
              <div className="space-y-4">
                {energyTips.length > 0 ? (
                  <ul className="space-y-4">
                    {energyTips.map((tip, index) => (
                      <li key={index} className="p-4 bg-card/80 rounded-lg border border-muted">
                        <div className="flex gap-3">
                          <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
                            <i className="ri-lightbulb-line text-primary"></i>
                          </div>
                          <p>{tip}</p>
                        </div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <i className="ri-information-line text-xl mb-2"></i>
                    <p>No energy-saving tips available at the moment.</p>
                    <p>Check back later for personalized recommendations.</p>
                  </div>
                )}
                
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => {
                    setIsLoadingTips(true);
                    fetch("/api/ai/energy-tips?userId=1")
                      .then(res => res.json())
                      .then(data => {
                        if (data.tips && Array.isArray(data.tips)) {
                          setEnergyTips(data.tips);
                        } else if (data.error && data.error.includes("quota")) {
                          // Handle OpenAI quota error specifically
                          console.error("OpenAI API quota exceeded:", data.error);
                          setEnergyTips([
                            "OpenAI API quota limit reached. Here are some general energy-saving tips instead:",
                            "Consider turning off lights in unoccupied rooms to reduce electricity usage.",
                            "Adjust the brightness of your lighting based on the time of day to optimize energy consumption.",
                            "Schedule your devices to turn off automatically during periods of inactivity."
                          ]);
                        }
                      })
                      .catch(err => {
                        console.error("Error refreshing tips:", err);
                        toast({
                          title: "Error",
                          description: "Failed to refresh recommendations.",
                          variant: "destructive"
                        });
                        // Provide fallback tips
                        setEnergyTips([
                          "Unable to connect to AI service. Here are some general energy-saving tips:",
                          "Consider turning off lights in unoccupied rooms to reduce electricity usage.",
                          "Adjust the brightness of your lighting based on the time of day to optimize energy consumption.",
                          "Schedule your devices to turn off automatically during periods of inactivity."
                        ]);
                      })
                      .finally(() => setIsLoadingTips(false));
                  }}
                >
                  <i className="ri-refresh-line mr-1"></i> Refresh Recommendations
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="text-xs text-muted-foreground flex justify-between items-center">
        <span>Powered by OpenAI's GPT</span>
        <Button variant="ghost" size="sm" asChild>
          <a href="https://openai.com" target="_blank" rel="noopener noreferrer">Learn more</a>
        </Button>
      </CardFooter>
    </Card>
  );
}