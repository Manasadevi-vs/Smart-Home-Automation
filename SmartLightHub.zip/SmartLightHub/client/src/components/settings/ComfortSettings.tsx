import { useState } from "react";
import { Preference } from "@shared/schema";
import { Switch } from "@/components/ui/switch";
import { lightColors } from "@/lib/deviceUtils";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

interface ComfortSettingsProps {
  preferences: Preference;
}

export default function ComfortSettings({ preferences }: ComfortSettingsProps) {
  const { toast } = useToast();
  const [lightBrightness, setLightBrightness] = useState<number>(preferences.lightBrightness || 65);
  const [fanSpeed, setFanSpeed] = useState<number>(preferences.fanSpeed || 50);
  const [autoAdjustLight, setAutoAdjustLight] = useState<boolean>(preferences.autoAdjustLight || false);
  const [autoAdjustFan, setAutoAdjustFan] = useState<boolean>(preferences.autoAdjustFan || false);
  const [minTemp, setMinTemp] = useState<number>(preferences.minTemperature || 22);
  const [maxTemp, setMaxTemp] = useState<number>(preferences.maxTemperature || 26);
  
  // Function to update preferences
  const updatePreferences = async (userId: number, updates: Partial<Preference>) => {
    try {
      await fetch(`/api/preferences/${userId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updates),
      });
    } catch (error) {
      console.error('Error updating preferences:', error);
      toast({
        title: "Error",
        description: "Failed to update preference. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  const handleLightBrightnessChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = parseInt(e.target.value);
    setLightBrightness(newValue);
    updatePreferences(preferences.userId, { lightBrightness: newValue });
  };
  
  const handleFanSpeedChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = parseInt(e.target.value);
    setFanSpeed(newValue);
    updatePreferences(preferences.userId, { fanSpeed: newValue });
  };
  
  const handleAutoAdjustLightChange = (checked: boolean) => {
    setAutoAdjustLight(checked);
    updatePreferences(preferences.userId, { autoAdjustLight: checked });
  };
  
  const handleAutoAdjustFanChange = (checked: boolean) => {
    setAutoAdjustFan(checked);
    updatePreferences(preferences.userId, { autoAdjustFan: checked });
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {/* Lighting Preferences */}
      <div>
        <h4 className="text-md font-medium mb-3 flex items-center">
          <i className="ri-lightbulb-line text-accent mr-2"></i> Lighting Preferences
        </h4>
        
        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span>Preferred brightness</span>
              <span className="text-muted-foreground">{lightBrightness}%</span>
            </div>
            <input 
              type="range" 
              min="0" 
              max="100" 
              value={lightBrightness} 
              onChange={handleLightBrightnessChange}
              className="w-full" 
            />
          </div>
          
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span>Color temperature by time</span>
            </div>
            <div className="grid grid-cols-3 gap-3 text-xs">
              <div className="bg-card/80 p-2 rounded-lg text-center">
                <div className="w-6 h-6 rounded-full bg-blue-100 mx-auto mb-1"></div>
                <span>Morning</span>
                <span className="block text-muted-foreground">Cool</span>
              </div>
              <div className="bg-card/80 p-2 rounded-lg text-center">
                <div className="w-6 h-6 rounded-full bg-yellow-50 mx-auto mb-1"></div>
                <span>Daytime</span>
                <span className="block text-muted-foreground">Neutral</span>
              </div>
              <div className="bg-card/80 p-2 rounded-lg text-center">
                <div className="w-6 h-6 rounded-full bg-yellow-100 mx-auto mb-1"></div>
                <span>Evening</span>
                <span className="block text-muted-foreground">Warm</span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-sm">Auto-adjust based on natural light</span>
            <Switch 
              checked={autoAdjustLight} 
              onCheckedChange={handleAutoAdjustLightChange} 
            />
          </div>
        </div>
      </div>

      {/* Fan/Climate Preferences */}
      <div>
        <h4 className="text-md font-medium mb-3 flex items-center">
          <i className="ri-windy-line text-primary mr-2"></i> Fan & Climate Preferences
        </h4>
        
        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span>Preferred fan speed</span>
              <span className="text-muted-foreground">
                {fanSpeed <= 0 ? "Off" : 
                  fanSpeed <= 25 ? "Low" : 
                  fanSpeed <= 75 ? "Medium" : "High"} ({fanSpeed}%)
              </span>
            </div>
            <input 
              type="range" 
              min="0" 
              max="100" 
              value={fanSpeed} 
              onChange={handleFanSpeedChange}
              className="w-full" 
            />
          </div>
          
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span>Optimal temperature range</span>
            </div>
            <div className="flex items-center justify-between bg-card/80 rounded-lg p-3">
              <div className="text-center">
                <span className="text-xs text-muted-foreground">Min</span>
                <div className="text-lg font-medium">{minTemp}°C</div>
              </div>

              <div className="h-0.5 flex-1 bg-muted mx-4 relative">
                <div className="absolute -top-1 left-1/4 w-2 h-2 bg-primary rounded-full"></div>
                <div className="absolute -top-1 right-1/4 w-2 h-2 bg-primary rounded-full"></div>
              </div>

              <div className="text-center">
                <span className="text-xs text-muted-foreground">Max</span>
                <div className="text-lg font-medium">{maxTemp}°C</div>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-sm">Auto-adjust based on occupancy</span>
            <Switch 
              checked={autoAdjustFan} 
              onCheckedChange={handleAutoAdjustFanChange} 
            />
          </div>
        </div>
      </div>
    </div>
  );
}
