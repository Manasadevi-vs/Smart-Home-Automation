import { db } from "../server/db";
import { achievements, challenges, insertAchievementSchema, insertChallengeSchema } from "../shared/schema";

async function initializeGamification() {
  console.log("Initializing gamification data...");

  // Remove existing achievements and challenges if any
  await db.delete(achievements);
  await db.delete(challenges);

  // Define achievements
  const achievementsData = [
    // Energy Saver achievements
    {
      name: "Energy Apprentice",
      description: "Save 100 watt-hours of energy by turning off lights when not in use",
      type: "energy_saver",
      icon: "save",
      pointsAwarded: 10,
      requirement: 100,
      tier: 1
    },
    {
      name: "Energy Expert", 
      description: "Save 500 watt-hours of energy through smart home optimization",
      type: "energy_saver",
      icon: "zap",
      pointsAwarded: 50,
      requirement: 500,
      tier: 2
    },
    {
      name: "Energy Master",
      description: "Save 1000 watt-hours of energy with your smart home",
      type: "energy_saver",
      icon: "bolt",
      pointsAwarded: 100,
      requirement: 1000,
      tier: 3
    },
    
    // Automation master achievements
    {
      name: "Rule Creator",
      description: "Create your first automation rule",
      type: "automation_master",
      icon: "git-branch",
      pointsAwarded: 15,
      requirement: 1,
      tier: 1
    },
    {
      name: "Automation Expert",
      description: "Create 5 different automation rules",
      type: "automation_master",
      icon: "workflow",
      pointsAwarded: 40,
      requirement: 5,
      tier: 2
    },
    {
      name: "Automation Wizard",
      description: "Have 10 active automation rules running",
      type: "automation_master",
      icon: "cpu",
      pointsAwarded: 100,
      requirement: 10,
      tier: 3
    },
    
    // Device management achievements
    {
      name: "First Steps",
      description: "Control your first smart device",
      type: "device_manager",
      icon: "switch",
      pointsAwarded: 5,
      requirement: 1,
      tier: 1
    },
    {
      name: "Device Enthusiast",
      description: "Control smart devices 50 times",
      type: "device_manager",
      icon: "toggle-right",
      pointsAwarded: 25,
      requirement: 50,
      tier: 2
    },
    {
      name: "Smart Home Master",
      description: "Control smart devices 200 times",
      type: "device_manager",
      icon: "command",
      pointsAwarded: 100,
      requirement: 200,
      tier: 3
    },
    
    // Smart lighting achievements
    {
      name: "Light Controller",
      description: "Turn on/off lights 10 times",
      type: "smart_lighter",
      icon: "lightbulb",
      pointsAwarded: 10,
      requirement: 10,
      tier: 1
    },
    {
      name: "Mood Maker",
      description: "Change light color 20 times",
      type: "smart_lighter",
      icon: "palette",
      pointsAwarded: 30,
      requirement: 20,
      tier: 2
    },
    {
      name: "Lighting Maestro",
      description: "Create perfect lighting scenes for morning, day and night",
      type: "smart_lighter",
      icon: "sun-moon",
      pointsAwarded: 50,
      requirement: 3,
      tier: 2
    },
    
    // Climate control achievements
    {
      name: "Fan Controller",
      description: "Adjust fan speed 10 times",
      type: "climate_controller",
      icon: "fan",
      pointsAwarded: 15,
      requirement: 10,
      tier: 1
    },
    {
      name: "Climate Optimizer",
      description: "Set up temperature-triggered automations",
      type: "climate_controller",
      icon: "thermometer",
      pointsAwarded: 40,
      requirement: 2,
      tier: 2
    },
    
    // Consistency achievements
    {
      name: "Regular User",
      description: "Use the smart home system for 3 days in a row",
      type: "daily_streak",
      icon: "calendar-check",
      pointsAwarded: 20,
      requirement: 3,
      tier: 1
    },
    {
      name: "Dedicated User",
      description: "Use the smart home system for 7 days in a row",
      type: "daily_streak",
      icon: "calendar-heart",
      pointsAwarded: 50,
      requirement: 7,
      tier: 2
    },
    {
      name: "Smart Home Champion",
      description: "Use the smart home system for 30 days in a row",
      type: "daily_streak",
      icon: "award",
      pointsAwarded: 200,
      requirement: 30,
      tier: 3
    }
  ];

  // Define challenges
  const challengesData = [
    // Daily challenges
    {
      name: "Energy Saving Day",
      description: "Reduce energy consumption by 10% today",
      type: "daily",
      pointsAwarded: 20,
      requirement: 10,
      icon: "leaf",
      startDate: new Date(),
      endDate: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours from now
      active: true
    },
    {
      name: "Light Efficiency Master",
      description: "Keep lights at 70% brightness or lower for a day",
      type: "daily",
      pointsAwarded: 15,
      requirement: 1,
      icon: "sun-dim",
      startDate: new Date(),
      endDate: new Date(Date.now() + 24 * 60 * 60 * 1000),
      active: true
    },
    {
      name: "Night Mode",
      description: "Turn off all lights by 11 PM",
      type: "daily",
      pointsAwarded: 10,
      requirement: 1,
      icon: "moon",
      startDate: new Date(),
      endDate: new Date(Date.now() + 24 * 60 * 60 * 1000),
      active: true
    },
    
    // Weekly challenges
    {
      name: "Rule Creator",
      description: "Create 3 new automation rules this week",
      type: "weekly",
      pointsAwarded: 50,
      requirement: 3,
      icon: "settings",
      startDate: new Date(),
      endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
      active: true
    },
    {
      name: "Smart Week",
      description: "Use your smart home system every day this week",
      type: "weekly",
      pointsAwarded: 70,
      requirement: 7,
      icon: "calendar-check",
      startDate: new Date(),
      endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      active: true
    },
    {
      name: "Energy Champion",
      description: "Keep weekly energy usage under the target threshold",
      type: "weekly",
      pointsAwarded: 100,
      requirement: 1,
      icon: "trending-down",
      startDate: new Date(),
      endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      active: true
    },
    
    // Monthly challenges
    {
      name: "Automation Expert",
      description: "Have your automation rules trigger at least 50 times this month",
      type: "monthly",
      pointsAwarded: 150,
      requirement: 50,
      icon: "cpu",
      startDate: new Date(),
      endDate: new Date(new Date().setMonth(new Date().getMonth() + 1)), // 1 month from now
      active: true
    },
    {
      name: "Energy Saving Month",
      description: "Save 30% on energy compared to previous month",
      type: "monthly",
      pointsAwarded: 200,
      requirement: 30,
      icon: "bolt",
      startDate: new Date(),
      endDate: new Date(new Date().setMonth(new Date().getMonth() + 1)),
      active: true
    },
    
    // Special challenges
    {
      name: "Holiday Lighting",
      description: "Set up special lighting scenes for the holiday season",
      type: "special",
      pointsAwarded: 50,
      requirement: 3,
      icon: "sparkles",
      startDate: new Date(),
      endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days for special event
      active: true
    }
  ];

  // Insert achievements
  for (const achievement of achievementsData) {
    const parsedAchievement = insertAchievementSchema.parse(achievement);
    await db.insert(achievements).values(parsedAchievement);
  }
  console.log(`Inserted ${achievementsData.length} achievements`);

  // Insert challenges
  for (const challenge of challengesData) {
    const parsedChallenge = insertChallengeSchema.parse(challenge);
    await db.insert(challenges).values(parsedChallenge);
  }
  console.log(`Inserted ${challengesData.length} challenges`);

  console.log("Gamification data initialization complete!");
}

// Run the initialization
initializeGamification()
  .catch(e => {
    console.error("Error initializing gamification data:", e);
    process.exit(1);
  })
  .finally(() => {
    console.log("Initialization script complete");
    process.exit(0);
  });