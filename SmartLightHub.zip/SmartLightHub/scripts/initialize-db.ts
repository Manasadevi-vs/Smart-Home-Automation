import { db } from "../server/db";
import {
  users, type InsertUser,
  rooms, type InsertRoom,
  devices, type InsertDevice,
  rules, type InsertRule,
  energyUsage, type InsertEnergyUsage,
  preferences, type InsertPreference
} from "../shared/schema";

async function main() {
  console.log("Initializing database with default data...");
  
  try {
    // Check if database already has data
    const existingUsers = await db.select().from(users);
    if (existingUsers.length > 0) {
      console.log("Database already has users, skipping initialization.");
      return;
    }
    
    // Add default user
    const defaultUser: InsertUser = {
      username: "admin",
      password: "admin",
      name: "Alex Johnson",
      role: "admin"
    };
    const [createdUser] = await db.insert(users).values(defaultUser).returning();
    console.log("Created default user:", createdUser.username);
    
    // Add default rooms
    const defaultRooms: InsertRoom[] = [
      { name: "Living Room", icon: "home" },
      { name: "Bedroom", icon: "bed" },
      { name: "Kitchen", icon: "utensils" },
      { name: "Bathroom", icon: "bath" },
      { name: "Office", icon: "briefcase" }
    ];
    const createdRooms = await db.insert(rooms).values(defaultRooms).returning();
    console.log(`Created ${createdRooms.length} default rooms`);
    
    // Add default devices
    const defaultDevices: InsertDevice[] = [
      { 
        name: "Ceiling Light", 
        type: "light", 
        roomId: 1, 
        topic: "smarthouse/livingroom/ceiling_light",
        status: true,
        brightness: 70,
        color: "warm"
      },
      { 
        name: "Floor Lamp", 
        type: "light", 
        roomId: 1, 
        topic: "smarthouse/livingroom/floor_lamp",
        status: false,
        brightness: 0,
        color: "cool"
      },
      { 
        name: "Ceiling Fan", 
        type: "fan", 
        roomId: 1, 
        topic: "smarthouse/livingroom/ceiling_fan",
        status: true,
        speed: 50,
        mode: "normal"
      },
      { 
        name: "Bedside Lamp", 
        type: "light", 
        roomId: 2, 
        topic: "smarthouse/bedroom/bedside_lamp",
        status: true,
        brightness: 50,
        color: "warm"
      },
      { 
        name: "Ceiling Light", 
        type: "light", 
        roomId: 2, 
        topic: "smarthouse/bedroom/ceiling_light",
        status: false,
        brightness: 0,
        color: "neutral"
      }
    ];
    const createdDevices = await db.insert(devices).values(defaultDevices).returning();
    console.log(`Created ${createdDevices.length} default devices`);
    
    // Add default rules
    const defaultRules: InsertRule[] = [
      {
        name: "Morning Routine",
        description: "Activates at 7:00 AM on weekdays",
        isActive: true,
        trigger: "time",
        triggerData: { time: "07:00", days: [1, 2, 3, 4, 5] },
        actions: [
          { deviceId: 4, status: true, brightness: 50 },
          { deviceId: 1, status: true, brightness: 70 },
          { deviceId: 3, status: true, speed: 30 }
        ]
      },
      {
        name: "Evening Mode",
        description: "Activates at sunset every day",
        isActive: true,
        trigger: "time",
        triggerData: { time: "sunset", days: [0, 1, 2, 3, 4, 5, 6] },
        actions: [
          { deviceId: 1, status: true, brightness: 60, color: "warm" },
          { deviceId: 4, status: true, brightness: 40, color: "warm" },
          { deviceId: 3, status: true, speed: 20, mode: "natural" }
        ]
      },
      {
        name: "Away Mode",
        description: "Manual activation",
        isActive: false,
        trigger: "manual",
        triggerData: {},
        actions: [
          { deviceId: 1, status: false },
          { deviceId: 2, status: false },
          { deviceId: 3, status: false },
          { deviceId: 4, status: false },
          { deviceId: 5, status: false }
        ]
      }
    ];
    const createdRules = await db.insert(rules).values(defaultRules).returning();
    console.log(`Created ${createdRules.length} default rules`);
    
    // Add default user preferences
    const defaultPreferences: InsertPreference = {
      userId: createdUser.id,
      lightBrightness: 65,
      lightColorMorning: "cool",
      lightColorDay: "neutral",
      lightColorEvening: "warm",
      autoAdjustLight: true,
      fanSpeed: 50,
      minTemperature: 22,
      maxTemperature: 26,
      autoAdjustFan: true
    };
    const [createdPreference] = await db.insert(preferences).values(defaultPreferences).returning();
    console.log("Created default user preferences");
    
    // Add sample energy usage data
    const now = new Date();
    const deviceIds = createdDevices.map(d => d.id);
    
    const energyUsageEntries: InsertEnergyUsage[] = [];
    
    // Create usage data for the past 24 hours
    for (let h = 0; h < 24; h++) {
      const timestamp = new Date(now);
      timestamp.setHours(now.getHours() - 24 + h);
      
      deviceIds.forEach(deviceId => {
        // Generate random energy usage between 10-100 Wh
        const value = Math.floor(Math.random() * 90) + 10;
        energyUsageEntries.push({
          deviceId,
          timestamp,
          value
        });
      });
    }
    
    const createdEnergyUsages = await db.insert(energyUsage).values(energyUsageEntries).returning();
    console.log(`Created ${createdEnergyUsages.length} energy usage records`);
    
    console.log("Database initialization complete!");
  } catch (error) {
    console.error("Error initializing database:", error);
    process.exit(1);
  }
  
  process.exit(0);
}

main();