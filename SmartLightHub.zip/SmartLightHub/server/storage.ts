import {
  users, type User, type InsertUser,
  rooms, type Room, type InsertRoom,
  devices, type Device, type InsertDevice,
  rules, type Rule, type InsertRule,
  energyUsage, type EnergyUsage, type InsertEnergyUsage,
  preferences, type Preference, type InsertPreference
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  
  // Room methods
  getAllRooms(): Promise<Room[]>;
  getRoom(id: number): Promise<Room | undefined>;
  createRoom(room: InsertRoom): Promise<Room>;
  
  // Device methods
  getAllDevices(): Promise<Device[]>;
  getDevice(id: number): Promise<Device | undefined>;
  getDevicesByRoom(roomId: number): Promise<Device[]>;
  getDeviceByTopic(topic: string): Promise<Device | undefined>;
  createDevice(device: InsertDevice): Promise<Device>;
  updateDevice(id: number, updates: Partial<Device>): Promise<Device | undefined>;
  
  // Rule methods
  getAllRules(): Promise<Rule[]>;
  getRule(id: number): Promise<Rule | undefined>;
  createRule(rule: InsertRule): Promise<Rule>;
  updateRule(id: number, updates: Partial<Rule>): Promise<Rule | undefined>;
  
  // Energy usage methods
  getEnergyUsage(startDate: Date | null): Promise<EnergyUsage[]>;
  getEnergyUsageByDevice(deviceId: number, startDate: Date | null): Promise<EnergyUsage[]>;
  recordEnergyUsage(usage: InsertEnergyUsage): Promise<EnergyUsage>;
  
  // User preferences methods
  getUserPreferences(userId: number): Promise<Preference | undefined>;
  createUserPreferences(preferences: InsertPreference): Promise<Preference>;
  updateUserPreferences(userId: number, updates: Partial<Preference>): Promise<Preference | undefined>;
}

import { db } from "./db";
import { eq, and, gte } from "drizzle-orm";

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const results = await db.select().from(users).where(eq(users.id, id));
    return results.length > 0 ? results[0] : undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const results = await db.select().from(users).where(eq(users.username, username));
    return results.length > 0 ? results[0] : undefined;
  }

  async getAllUsers(): Promise<User[]> {
    return db.select().from(users);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const results = await db.insert(users).values(insertUser).returning();
    return results[0];
  }
  
  // Room methods
  async getAllRooms(): Promise<Room[]> {
    return db.select().from(rooms);
  }
  
  async getRoom(id: number): Promise<Room | undefined> {
    const results = await db.select().from(rooms).where(eq(rooms.id, id));
    return results.length > 0 ? results[0] : undefined;
  }
  
  async createRoom(insertRoom: InsertRoom): Promise<Room> {
    const results = await db.insert(rooms).values(insertRoom).returning();
    return results[0];
  }
  
  // Device methods
  async getAllDevices(): Promise<Device[]> {
    return db.select().from(devices);
  }
  
  async getDevice(id: number): Promise<Device | undefined> {
    const results = await db.select().from(devices).where(eq(devices.id, id));
    return results.length > 0 ? results[0] : undefined;
  }
  
  async getDevicesByRoom(roomId: number): Promise<Device[]> {
    return db.select().from(devices).where(eq(devices.roomId, roomId));
  }
  
  async getDeviceByTopic(topic: string): Promise<Device | undefined> {
    const results = await db.select().from(devices).where(eq(devices.topic, topic));
    return results.length > 0 ? results[0] : undefined;
  }
  
  async createDevice(insertDevice: InsertDevice): Promise<Device> {
    const results = await db.insert(devices).values(insertDevice).returning();
    return results[0];
  }
  
  async updateDevice(id: number, updates: Partial<Device>): Promise<Device | undefined> {
    const results = await db.update(devices)
      .set(updates)
      .where(eq(devices.id, id))
      .returning();
    return results.length > 0 ? results[0] : undefined;
  }
  
  // Rule methods
  async getAllRules(): Promise<Rule[]> {
    return db.select().from(rules);
  }
  
  async getRule(id: number): Promise<Rule | undefined> {
    const results = await db.select().from(rules).where(eq(rules.id, id));
    return results.length > 0 ? results[0] : undefined;
  }
  
  async createRule(insertRule: InsertRule): Promise<Rule> {
    const results = await db.insert(rules).values(insertRule).returning();
    return results[0];
  }
  
  async updateRule(id: number, updates: Partial<Rule>): Promise<Rule | undefined> {
    const results = await db.update(rules)
      .set(updates)
      .where(eq(rules.id, id))
      .returning();
    return results.length > 0 ? results[0] : undefined;
  }
  
  // Energy usage methods
  async getEnergyUsage(startDate: Date | null): Promise<EnergyUsage[]> {
    if (!startDate) {
      return db.select().from(energyUsage);
    }
    
    return db.select()
      .from(energyUsage)
      .where(gte(energyUsage.timestamp, startDate));
  }
  
  async getEnergyUsageByDevice(deviceId: number, startDate: Date | null): Promise<EnergyUsage[]> {
    if (!startDate) {
      return db.select()
        .from(energyUsage)
        .where(eq(energyUsage.deviceId, deviceId));
    }
    
    return db.select()
      .from(energyUsage)
      .where(
        and(
          eq(energyUsage.deviceId, deviceId),
          gte(energyUsage.timestamp, startDate)
        )
      );
  }
  
  async recordEnergyUsage(insertUsage: InsertEnergyUsage): Promise<EnergyUsage> {
    const results = await db.insert(energyUsage).values(insertUsage).returning();
    return results[0];
  }
  
  // User preferences methods
  async getUserPreferences(userId: number): Promise<Preference | undefined> {
    const results = await db.select()
      .from(preferences)
      .where(eq(preferences.userId, userId));
    return results.length > 0 ? results[0] : undefined;
  }
  
  async createUserPreferences(insertPreference: InsertPreference): Promise<Preference> {
    const results = await db.insert(preferences).values(insertPreference).returning();
    return results[0];
  }
  
  async updateUserPreferences(userId: number, updates: Partial<Preference>): Promise<Preference | undefined> {
    const prefs = await this.getUserPreferences(userId);
    if (!prefs) return undefined;
    
    const results = await db.update(preferences)
      .set(updates)
      .where(eq(preferences.id, prefs.id))
      .returning();
    return results.length > 0 ? results[0] : undefined;
  }
}

export const storage = new DatabaseStorage();
