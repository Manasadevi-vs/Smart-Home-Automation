import { db } from "../db";
import { 
  users, achievements, userAchievements, challenges, userChallenges,
  User, Achievement, UserAchievement, Challenge, UserChallenge
} from "../../shared/schema";
import { eq, and, lt, gte } from "drizzle-orm";

/**
 * Updates a user's points
 */
export async function updateUserPoints(userId: number, pointsToAdd: number): Promise<User> {
  // Get current user data
  const [user] = await db.select().from(users).where(eq(users.id, userId));
  
  if (!user) {
    throw new Error(`User with ID ${userId} not found`);
  }
  
  // Calculate new points and potentially new level
  const currentPoints = user.points || 0;
  const currentLevel = user.level || 1;
  const newPoints = currentPoints + pointsToAdd;
  let newLevel = currentLevel;
  
  // Simple level calculation: level up every 100 points
  const calculatedLevel = Math.floor(newPoints / 100) + 1;
  if (calculatedLevel > currentLevel) {
    newLevel = calculatedLevel;
  }
  
  // Update the user
  const [updatedUser] = await db
    .update(users)
    .set({ 
      points: newPoints,
      level: newLevel,
      lastActive: new Date()
    })
    .where(eq(users.id, userId))
    .returning();
    
  return updatedUser;
}

/**
 * Updates a user's daily streak
 */
export async function updateUserStreak(userId: number): Promise<User> {
  // Get current user data
  const [user] = await db.select().from(users).where(eq(users.id, userId));
  
  if (!user) {
    throw new Error(`User with ID ${userId} not found`);
  }
  
  // Check if last activity was within the last 48 hours but not in the last 24 hours
  // This ensures that the streak is only updated once per day
  const now = new Date();
  const lastActive = user.lastActive || new Date(0); // Default to epoch if null
  const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  const twoDaysAgo = new Date(now.getTime() - 48 * 60 * 60 * 1000);
  
  const currentStreak = user.streak || 0;
  let newStreak = currentStreak;
  
  if (lastActive < oneDayAgo && lastActive >= twoDaysAgo) {
    // User was active yesterday, increment streak
    newStreak += 1;
  } else if (lastActive < twoDaysAgo) {
    // User missed a day, reset streak
    newStreak = 1;
  }
  
  // Update the user
  const [updatedUser] = await db
    .update(users)
    .set({ 
      streak: newStreak,
      lastActive: now
    })
    .where(eq(users.id, userId))
    .returning();
    
  return updatedUser;
}

/**
 * Get all achievements
 */
export async function getAllAchievements(): Promise<Achievement[]> {
  return db.select().from(achievements);
}

/**
 * Get user achievements
 */
export async function getUserAchievements(userId: number): Promise<{
  achievement: Achievement;
  progress: number;
  completed: boolean;
  completedAt: Date | null;
}[]> {
  // Get all achievements
  const allAchievements = await getAllAchievements();
  
  // Get user's achievement progress
  const userAchievementsData = await db
    .select()
    .from(userAchievements)
    .where(eq(userAchievements.userId, userId));
  
  // Map user achievements to the full achievement data
  return allAchievements.map(achievement => {
    const userAchievement = userAchievementsData.find(ua => ua.achievementId === achievement.id);
    
    return {
      achievement,
      progress: userAchievement?.progress || 0,
      completed: userAchievement?.completed || false,
      completedAt: userAchievement?.completedAt || null
    };
  });
}

/**
 * Update achievement progress
 */
export async function updateAchievementProgress(
  userId: number, 
  achievementType: string, 
  incrementBy: number = 1
): Promise<UserAchievement[]> {
  // Get all achievements of this type
  const matchingAchievements = await db
    .select()
    .from(achievements)
    .where(eq(achievements.type, achievementType));
  
  if (matchingAchievements.length === 0) {
    return [];
  }
  
  const updatedAchievements: UserAchievement[] = [];
  
  // Update each matching achievement
  for (const achievement of matchingAchievements) {
    // Check if user already has this achievement
    const [existingProgress] = await db
      .select()
      .from(userAchievements)
      .where(
        and(
          eq(userAchievements.userId, userId),
          eq(userAchievements.achievementId, achievement.id)
        )
      );
    
    if (existingProgress) {
      // Only update if not already completed
      if (!existingProgress.completed) {
        const currentProgress = existingProgress.progress || 0;
        const newProgress = currentProgress + incrementBy;
        const isCompleted = newProgress >= achievement.requirement;
        
        // Update the progress
        const [updated] = await db
          .update(userAchievements)
          .set({ 
            progress: newProgress,
            completed: isCompleted,
            completedAt: isCompleted ? new Date() : null
          })
          .where(
            and(
              eq(userAchievements.userId, userId),
              eq(userAchievements.achievementId, achievement.id)
            )
          )
          .returning();
          
        updatedAchievements.push(updated);
        
        // Award points if completed
        if (isCompleted) {
          await updateUserPoints(userId, achievement.pointsAwarded || 10);
        }
      }
    } else {
      // Create new progress entry
      const progress = incrementBy;
      const isCompleted = progress >= achievement.requirement;
      
      const [newProgress] = await db
        .insert(userAchievements)
        .values({
          userId,
          achievementId: achievement.id,
          progress,
          completed: isCompleted,
          completedAt: isCompleted ? new Date() : null
        })
        .returning();
        
      updatedAchievements.push(newProgress);
      
      // Award points if completed
      if (isCompleted) {
        await updateUserPoints(userId, achievement.pointsAwarded || 10);
      }
    }
  }
  
  return updatedAchievements;
}

/**
 * Get active challenges
 */
export async function getActiveChallenges(): Promise<Challenge[]> {
  const now = new Date();
  
  return db
    .select()
    .from(challenges)
    .where(
      and(
        eq(challenges.active, true),
        lt(challenges.startDate, now),
        gte(challenges.endDate || now, now) // Default to now if endDate is null
      )
    );
}

/**
 * Get user challenges
 */
export async function getUserChallenges(userId: number): Promise<{
  challenge: Challenge;
  progress: number;
  completed: boolean;
  completedAt: Date | null;
}[]> {
  // Get active challenges
  const activeChallenges = await getActiveChallenges();
  
  // Get user's challenge progress
  const userChallengesData = await db
    .select()
    .from(userChallenges)
    .where(eq(userChallenges.userId, userId));
  
  // Map user challenges to the full challenge data
  return activeChallenges.map(challenge => {
    const userChallenge = userChallengesData.find(uc => uc.challengeId === challenge.id);
    
    return {
      challenge,
      progress: userChallenge?.progress || 0,
      completed: userChallenge?.completed || false,
      completedAt: userChallenge?.completedAt || null
    };
  });
}

/**
 * Update challenge progress
 */
export async function updateChallengeProgress(
  userId: number, 
  challengeType: string, 
  incrementBy: number = 1
): Promise<UserChallenge[]> {
  // Get active challenges of this type
  const now = new Date();
  const matchingChallenges = await db
    .select()
    .from(challenges)
    .where(
      and(
        eq(challenges.type, challengeType),
        eq(challenges.active, true),
        lt(challenges.startDate, now),
        gte(challenges.endDate || now, now) // Default to now if endDate is null
      )
    );
  
  if (matchingChallenges.length === 0) {
    return [];
  }
  
  const updatedChallenges: UserChallenge[] = [];
  
  // Update each matching challenge
  for (const challenge of matchingChallenges) {
    // Check if user already has this challenge
    const [existingProgress] = await db
      .select()
      .from(userChallenges)
      .where(
        and(
          eq(userChallenges.userId, userId),
          eq(userChallenges.challengeId, challenge.id)
        )
      );
    
    if (existingProgress) {
      // Only update if not already completed
      if (!existingProgress.completed) {
        const currentProgress = existingProgress.progress || 0;
        const newProgress = currentProgress + incrementBy;
        const isCompleted = newProgress >= challenge.requirement;
        
        // Update the progress
        const [updated] = await db
          .update(userChallenges)
          .set({ 
            progress: newProgress,
            completed: isCompleted,
            completedAt: isCompleted ? new Date() : null
          })
          .where(
            and(
              eq(userChallenges.userId, userId),
              eq(userChallenges.challengeId, challenge.id)
            )
          )
          .returning();
          
        updatedChallenges.push(updated);
        
        // Award points if completed
        if (isCompleted) {
          await updateUserPoints(userId, challenge.pointsAwarded || 20);
        }
      }
    } else {
      // Create new progress entry
      const progress = incrementBy;
      const isCompleted = progress >= challenge.requirement;
      
      const [newProgress] = await db
        .insert(userChallenges)
        .values({
          userId,
          challengeId: challenge.id,
          progress,
          completed: isCompleted,
          completedAt: isCompleted ? new Date() : null
        })
        .returning();
        
      updatedChallenges.push(newProgress);
      
      // Award points if completed
      if (isCompleted) {
        await updateUserPoints(userId, challenge.pointsAwarded || 20);
      }
    }
  }
  
  return updatedChallenges;
}

/**
 * Get user gamification profile
 */
export async function getUserGamificationProfile(userId: number): Promise<{
  user: User;
  achievements: {
    total: number;
    completed: number;
    inProgress: number;
  };
  challenges: {
    active: number;
    completed: number;
    inProgress: number;
  };
  nextLevel: {
    current: number;
    pointsToNext: number;
    progress: number;
  };
  streak: number;
}> {
  // Get user data
  const [user] = await db.select().from(users).where(eq(users.id, userId));
  
  if (!user) {
    throw new Error(`User with ID ${userId} not found`);
  }
  
  // Get achievements
  const userAchievementsData = await getUserAchievements(userId);
  const totalAchievements = userAchievementsData.length;
  const completedAchievements = userAchievementsData.filter(ua => ua.completed).length;
  const inProgressAchievements = userAchievementsData.filter(ua => !ua.completed && ua.progress > 0).length;
  
  // Get challenges
  const userChallengesData = await getUserChallenges(userId);
  const activeChallenges = userChallengesData.length;
  const completedChallenges = userChallengesData.filter(uc => uc.completed).length;
  const inProgressChallenges = userChallengesData.filter(uc => !uc.completed && uc.progress > 0).length;
  
  // Calculate next level progress
  const currentLevel = user.level || 1;
  const currentPoints = user.points || 0;
  const nextLevel = currentLevel + 1;
  const pointsForNextLevel = nextLevel * 100;
  const pointsNeeded = pointsForNextLevel - currentPoints;
  const pointsProgress = (currentPoints % 100) / 100; // Progress percentage to next level
  
  return {
    user,
    achievements: {
      total: totalAchievements,
      completed: completedAchievements,
      inProgress: inProgressAchievements
    },
    challenges: {
      active: activeChallenges,
      completed: completedChallenges,
      inProgress: inProgressChallenges
    },
    nextLevel: {
      current: currentLevel,
      pointsToNext: pointsNeeded,
      progress: pointsProgress
    },
    streak: user.streak || 0
  };
}

/**
 * Process device interaction for gamification
 */
export async function processDeviceInteraction(userId: number, deviceId: number, deviceType: string): Promise<void> {
  // Update device manager achievement progress
  await updateAchievementProgress(userId, "device_manager", 1);
  
  // Update specific device type achievements
  if (deviceType === "light") {
    await updateAchievementProgress(userId, "smart_lighter", 1);
  } else if (deviceType === "fan") {
    await updateAchievementProgress(userId, "climate_controller", 1);
  }
  
  // Update related challenges
  await updateChallengeProgress(userId, "daily", 1);
  
  // Update user streak
  await updateUserStreak(userId);
}

/**
 * Process energy savings for gamification
 */
export async function processEnergySaving(userId: number, wattHoursSaved: number): Promise<void> {
  // Update energy saver achievement progress
  await updateAchievementProgress(userId, "energy_saver", wattHoursSaved);
  
  // Update energy saving challenges
  if (wattHoursSaved > 0) {
    await updateChallengeProgress(userId, "daily", 1);
    await updateChallengeProgress(userId, "weekly", 1);
    await updateChallengeProgress(userId, "monthly", 1);
  }
}

/**
 * Process automation rule creation/trigger for gamification
 */
export async function processAutomationActivity(userId: number, isNewRule: boolean = false): Promise<void> {
  // Update automation master achievement progress
  await updateAchievementProgress(userId, "automation_master", isNewRule ? 1 : 0);
  
  // Update related challenges
  if (isNewRule) {
    await updateChallengeProgress(userId, "weekly", 1);
  }
}