import OpenAI from "openai";
import { Device, EnergyUsage, Rule, Preference } from "@shared/schema";

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * Generate energy-saving recommendations based on device usage and energy data
 */
export async function generateEnergySavingTips(
  devices: Device[],
  energyUsage: EnergyUsage[],
  preferences: Preference
): Promise<string[]> {
  try {
    // Create a prompt with the relevant data
    const activeDevices = devices.filter(device => device.status);
    const totalEnergyUsage = energyUsage.reduce((total, usage) => total + usage.value, 0);
    
    const prompt = `
      Based on the following smart home data, provide 3 personalized energy-saving tips:
      
      Active devices (${activeDevices.length}/${devices.length}):
      ${activeDevices.map(d => `- ${d.name} (${d.type}, brightness: ${d.brightness}%, room: ${d.roomId})`).join('\n')}
      
      Total energy usage: ${totalEnergyUsage.toFixed(2)} kWh
      
      User preferences:
      - Preferred light brightness: ${preferences.lightBrightness}%
      - Preferred temperature range: ${preferences.minTemperature}°C - ${preferences.maxTemperature}°C
      - Fan speed preference: ${preferences.fanSpeed}/100
      - Auto-adjust light: ${preferences.autoAdjustLight ? 'Yes' : 'No'}
      - Auto-adjust fan: ${preferences.autoAdjustFan ? 'Yes' : 'No'}
      
      Each tip should be practical, specific to this data, and focus on reducing energy usage while maintaining comfort.
      Format each tip as a single paragraph with actionable advice.
    `;

    try {
      // Call OpenAI API to generate recommendations
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are a smart home energy efficiency expert. Provide practical, specific recommendations to save energy based on device usage patterns and user preferences."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        temperature: 0.7,
        max_tokens: 500,
      });

      // Process the response
      const content = response.choices[0].message.content;
      if (!content) return ["Unable to generate recommendations at this time."];
      
      // Split into separate tips and clean up
      return content
        .split('\n\n')
        .filter(tip => tip.trim().length > 0)
        .map(tip => tip.trim());
        
    } catch (openAiError: any) {
      console.error("OpenAI API error:", openAiError);
      
      // Check if it's a quota exceeded error
      if (openAiError.code === 'insufficient_quota' || (openAiError.error && openAiError.error.code === 'insufficient_quota')) {
        return [
          "Unable to generate AI recommendations due to service limitations. Here are some general tips:",
          "Consider adjusting your lighting brightness to around 60-70% in rooms where full brightness isn't necessary.",
          "Turn off lights in unoccupied rooms to reduce electricity consumption.",
          "Schedule your fans to automatically adjust based on the time of day to optimize energy usage."
        ];
      }
      
      // For other OpenAI errors
      return ["The AI recommendation service is currently unavailable. Please check back later for personalized energy-saving tips."];
    }
  } catch (error) {
    console.error("Error generating energy-saving tips:", error);
    return ["Unable to generate AI recommendations. Please try again later."];
  }
}

/**
 * Process natural language commands for controlling devices
 */
export async function processNaturalLanguageCommand(
  command: string,
  devices: Device[],
  rooms: { id: number; name: string }[]
): Promise<{
  success: boolean;
  message: string;
  actions?: Array<{
    deviceId: number;
    deviceName: string;
    action: string;
    parameters?: Record<string, any>;
  }>;
}> {
  try {
    // Create a system prompt with available devices and rooms
    const systemPrompt = `
      You are a smart home AI assistant that converts natural language commands into specific device actions.
      Available devices:
      ${devices.map(d => `- ${d.name} (${d.type}, in ${rooms.find(r => r.id === d.roomId)?.name || 'Unknown room'})`).join('\n')}
      
      Available rooms:
      ${rooms.map(r => `- ${r.name} (ID: ${r.id})`).join('\n')}
      
      Parse the user's command and respond with a JSON object containing:
      1. success: boolean - whether the command can be executed
      2. message: string - a user-friendly message about what will happen or why it failed
      3. actions: array of actions to take (if success is true), where each action has:
         - deviceId: the ID of the device to control
         - deviceName: the name of the device for confirmation
         - action: what to do (e.g., "turn_on", "turn_off", "set_brightness", "set_speed")
         - parameters: any parameters needed (e.g., brightness percentage)
      
      Only include devices that exist in the available list. If a command is ambiguous or refers to unavailable devices, set success to false with an appropriate message.
    `;

    try {
      // Call OpenAI API to process the command
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: systemPrompt
          },
          {
            role: "user",
            content: command
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.2,
      });
  
      const content = response.choices[0].message.content;
      if (!content) {
        return {
          success: false,
          message: "Unable to process your command. Please try again or use the device controls directly."
        };
      }
      
      // Parse the JSON response
      return JSON.parse(content);
      
    } catch (openAiError: any) {
      console.error("OpenAI API error:", openAiError);
      
      // Check if it's a quota exceeded error
      if (openAiError.code === 'insufficient_quota' || (openAiError.error && openAiError.error.code === 'insufficient_quota')) {
        return {
          success: false,
          message: "The AI assistant is currently unavailable. Please use the direct device controls instead."
        };
      }
      
      // For other OpenAI errors
      return {
        success: false,
        message: "The AI assistant is having trouble understanding your command. Please try using the device controls directly."
      };
    }
  } catch (error) {
    console.error("Error processing natural language command:", error);
    return {
      success: false,
      message: "An error occurred while processing your command. Please try the manual device controls instead."
    };
  }
}

/**
 * Generate smart automation rule suggestions based on device usage patterns
 */
export async function generateAutomationSuggestions(
  devices: Device[],
  energyUsage: EnergyUsage[],
  existingRules: Rule[]
): Promise<Array<{
  name: string;
  description: string;
  trigger: string;
  conditions: string;
  actions: string;
  benefit: string;
}>> {
  try {
    // Create a prompt with the relevant data
    const deviceData = devices.map(d => ({
      id: d.id,
      name: d.name,
      type: d.type,
      roomId: d.roomId,
      status: d.status,
      usage: energyUsage.filter(u => u.deviceId === d.id).reduce((total, u) => total + u.value, 0)
    }));
    
    const existingRuleNames = existingRules.map(r => r.name);
    
    const prompt = `
      Based on the following smart home data, suggest 2-3 new automation rules that would improve energy efficiency and user comfort:
      
      Device data:
      ${JSON.stringify(deviceData, null, 2)}
      
      Existing rules (avoid duplicates):
      ${existingRuleNames.join(', ')}
      
      For each suggested rule, provide:
      1. name: A short, descriptive name
      2. description: A user-friendly explanation of what the rule does
      3. trigger: When the rule should run (time-based, device state change, etc.)
      4. conditions: Under what conditions the rule should execute
      5. actions: What device actions should be taken
      6. benefit: The energy saving or comfort benefit to the user
      
      Format the response as a JSON array of rule objects.
    `;

    try {
      // Call OpenAI API to generate rule suggestions
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are a smart home automation expert. Generate practical automation rule suggestions based on device usage patterns to improve energy efficiency and user comfort."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.7,
      });

      const content = response.choices[0].message.content;
      if (!content) return [];
      
      // Parse the JSON response
      const results = JSON.parse(content);
      return Array.isArray(results) ? results : results.suggestions || [];
      
    } catch (openAiError: any) {
      console.error("OpenAI API error:", openAiError);
      
      // Check if it's a quota exceeded error
      if (openAiError.code === 'insufficient_quota' || (openAiError.error && openAiError.error.code === 'insufficient_quota')) {
        // Return default automation rule suggestions
        return [
          {
            name: "Evening Light Dimming",
            description: "Automatically reduce light brightness in the evening to save energy and create a more relaxing atmosphere.",
            trigger: "Time-based (8:00 PM daily)",
            conditions: "Only if lights are on and at brightness greater than 70%",
            actions: "Reduce all active lights to 60% brightness",
            benefit: "Saves energy and creates a more comfortable evening environment while maintaining adequate lighting."
          },
          {
            name: "Inactive Room Auto-off",
            description: "Turn off lights and fans in rooms that have been inactive for a specified period.",
            trigger: "No motion detected for 30 minutes",
            conditions: "Device (light or fan) is on in the room",
            actions: "Turn off the device",
            benefit: "Prevents energy waste from devices left on in unoccupied rooms."
          }
        ];
      }
      
      // For other OpenAI errors
      return [];
    }
  } catch (error) {
    console.error("Error generating automation suggestions:", error);
    return [];
  }
}