import express, { type Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import {
  insertDeviceSchema,
  insertRoomSchema,
  insertRuleSchema,
  insertUserSchema,
  insertPreferenceSchema,
  insertEnergyUsageSchema
} from "@shared/schema";
import * as mqtt from "mqtt";
import { 
  generateEnergySavingTips, 
  processNaturalLanguageCommand,
  generateAutomationSuggestions 
} from "./services/aiService";
import { 
  getAllAchievements, 
  getUserAchievements, 
  getActiveChallenges, 
  getUserChallenges,
  getUserGamificationProfile,
  processDeviceInteraction,
  processEnergySaving,
  processAutomationActivity,
  updateUserPoints,
  updateUserStreak
} from "./services/gamificationService";

// MQTT client setup
let mqttClient: mqtt.MqttClient | null = null;
const mqttBroker = process.env.MQTT_BROKER || "mqtt://localhost";
const mqttOptions = {
  clientId: `smarthouse_server_${Math.random().toString(16).substring(2, 8)}`,
  username: process.env.MQTT_USERNAME,
  password: process.env.MQTT_PASSWORD,
};

// WebSocket clients
const wsClients = new Set<WebSocket>();

// Connect to MQTT broker
function connectMqtt() {
  try {
    console.log("MQTT connection disabled - using mock mode for demo");
    // For demo purposes, we'll use a mock setup instead of a real MQTT connection
    // This allows the demo to run without an actual MQTT broker
    
    // Simulate MQTT connection status for clients
    setTimeout(() => {
      broadcastToWebSocketClients({
        type: 'mqtt_status',
        connected: true,
        mock: true
      });
    }, 2000);
    
    return;
    
    /* Real MQTT connection code is disabled for the demo
    mqttClient = mqtt.connect(mqttBroker, mqttOptions);
    
    mqttClient.on("connect", () => {
      console.log("Connected to MQTT broker");
      // Subscribe to all device topics
      mqttClient?.subscribe("smarthouse/#");
    });

    mqttClient.on("message", (topic, message) => {
      // Forward MQTT messages to all WebSocket clients
      const payload = {
        type: "mqtt_message",
        topic,
        message: message.toString()
      };
      
      broadcastToWebSocketClients(payload);
    });

    mqttClient.on("error", (err) => {
      console.error("MQTT error:", err);
    });

    mqttClient.on("close", () => {
      console.log("MQTT connection closed");
    });
    */
  } catch (error) {
    console.error("MQTT connection error:", error);
  }
}

// Broadcast message to all WebSocket clients
function broadcastToWebSocketClients(data: any) {
  const message = JSON.stringify(data);
  wsClients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(message);
    }
  });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Connect to MQTT broker
  connectMqtt();

  // API routes
  const apiRouter = express.Router();
  
  // Users
  apiRouter.get("/users", async (_req, res) => {
    const users = await storage.getAllUsers();
    res.json(users);
  });

  apiRouter.get("/users/:id", async (req, res) => {
    const user = await storage.getUser(Number(req.params.id));
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    res.json(user);
  });

  apiRouter.post("/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      res.status(400).json({ message: String(error) });
    }
  });

  // Rooms
  apiRouter.get("/rooms", async (_req, res) => {
    const rooms = await storage.getAllRooms();
    res.json(rooms);
  });

  apiRouter.post("/rooms", async (req, res) => {
    try {
      const roomData = insertRoomSchema.parse(req.body);
      const room = await storage.createRoom(roomData);
      res.status(201).json(room);
    } catch (error) {
      res.status(400).json({ message: String(error) });
    }
  });

  // Devices
  apiRouter.get("/devices", async (_req, res) => {
    const devices = await storage.getAllDevices();
    res.json(devices);
  });

  apiRouter.get("/devices/:id", async (req, res) => {
    const device = await storage.getDevice(Number(req.params.id));
    if (!device) {
      return res.status(404).json({ message: "Device not found" });
    }
    res.json(device);
  });

  apiRouter.get("/rooms/:roomId/devices", async (req, res) => {
    const devices = await storage.getDevicesByRoom(Number(req.params.roomId));
    res.json(devices);
  });

  apiRouter.post("/devices", async (req, res) => {
    try {
      const deviceData = insertDeviceSchema.parse(req.body);
      const device = await storage.createDevice(deviceData);
      res.status(201).json(device);
    } catch (error) {
      res.status(400).json({ message: String(error) });
    }
  });

  apiRouter.put("/devices/:id", async (req, res) => {
    try {
      const deviceId = Number(req.params.id);
      const updates = req.body;
      
      const device = await storage.updateDevice(deviceId, updates);
      if (!device) {
        return res.status(404).json({ message: "Device not found" });
      }
      
      // Publish to MQTT if connected
      if (mqttClient && mqttClient.connected && device.topic) {
        const payload = JSON.stringify({
          status: device.status,
          brightness: device.brightness,
          color: device.color,
          speed: device.speed,
          mode: device.mode
        });
        
        mqttClient.publish(device.topic, payload);
      }
      
      res.json(device);
    } catch (error) {
      res.status(400).json({ message: String(error) });
    }
  });

  // Automation Rules
  apiRouter.get("/rules", async (_req, res) => {
    const rules = await storage.getAllRules();
    res.json(rules);
  });

  apiRouter.post("/rules", async (req, res) => {
    try {
      const ruleData = insertRuleSchema.parse(req.body);
      const rule = await storage.createRule(ruleData);
      res.status(201).json(rule);
    } catch (error) {
      res.status(400).json({ message: String(error) });
    }
  });

  apiRouter.put("/rules/:id", async (req, res) => {
    try {
      const ruleId = Number(req.params.id);
      const updates = req.body;
      
      const rule = await storage.updateRule(ruleId, updates);
      if (!rule) {
        return res.status(404).json({ message: "Rule not found" });
      }
      
      res.json(rule);
    } catch (error) {
      res.status(400).json({ message: String(error) });
    }
  });

  // Energy Usage
  apiRouter.get("/energy-usage", async (req, res) => {
    const { period, deviceId } = req.query;
    
    let startDate: Date | null = null;
    const now = new Date();
    
    if (period === "day") {
      startDate = new Date(now);
      startDate.setHours(0, 0, 0, 0);
    } else if (period === "week") {
      startDate = new Date(now);
      startDate.setDate(now.getDate() - 7);
    } else if (period === "month") {
      startDate = new Date(now);
      startDate.setMonth(now.getMonth() - 1);
    }
    
    let energyData;
    if (deviceId) {
      energyData = await storage.getEnergyUsageByDevice(Number(deviceId), startDate);
    } else {
      energyData = await storage.getEnergyUsage(startDate);
    }
    
    res.json(energyData);
  });

  apiRouter.post("/energy-usage", async (req, res) => {
    try {
      const energyData = insertEnergyUsageSchema.parse(req.body);
      const usage = await storage.recordEnergyUsage(energyData);
      res.status(201).json(usage);
    } catch (error) {
      res.status(400).json({ message: String(error) });
    }
  });

  // User Preferences
  apiRouter.get("/preferences/:userId", async (req, res) => {
    const preferences = await storage.getUserPreferences(Number(req.params.userId));
    if (!preferences) {
      return res.status(404).json({ message: "Preferences not found" });
    }
    res.json(preferences);
  });

  apiRouter.post("/preferences", async (req, res) => {
    try {
      const preferencesData = insertPreferenceSchema.parse(req.body);
      const preferences = await storage.createUserPreferences(preferencesData);
      res.status(201).json(preferences);
    } catch (error) {
      res.status(400).json({ message: String(error) });
    }
  });

  apiRouter.put("/preferences/:userId", async (req, res) => {
    try {
      const userId = Number(req.params.userId);
      const updates = req.body;
      
      const preferences = await storage.updateUserPreferences(userId, updates);
      if (!preferences) {
        return res.status(404).json({ message: "Preferences not found" });
      }
      
      res.json(preferences);
    } catch (error) {
      res.status(400).json({ message: String(error) });
    }
  });

  // MQTT route - for manual publishing
  apiRouter.post("/mqtt/publish", async (req, res) => {
    const { topic, message } = req.body;
    
    if (!topic || !message) {
      return res.status(400).json({ message: "Topic and message are required" });
    }
    
    if (!mqttClient || !mqttClient.connected) {
      return res.status(503).json({ message: "MQTT client not connected" });
    }
    
    try {
      mqttClient.publish(topic, JSON.stringify(message));
      res.json({ success: true, topic, message });
    } catch (error) {
      res.status(500).json({ message: String(error) });
    }
  });

  // Get MQTT status
  apiRouter.get("/mqtt/status", (_req, res) => {
    res.json({
      connected: Boolean(mqttClient?.connected),
      broker: mqttBroker,
      clientId: mqttOptions.clientId
    });
  });

  // AI Assistant Endpoints
  
  // Get energy-saving recommendations
  apiRouter.get("/ai/energy-tips", async (req, res) => {
    try {
      const userId = Number(req.query.userId) || 1;
      
      // Load required data
      const devices = await storage.getAllDevices();
      const preferences = await storage.getUserPreferences(userId);
      
      if (!preferences) {
        return res.status(404).json({ message: "User preferences not found" });
      }
      
      // Get energy usage for last 7 days
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - 7);
      const energyUsage = await storage.getEnergyUsage(startDate);
      
      // Generate AI tips
      const tips = await generateEnergySavingTips(devices, energyUsage, preferences);
      
      res.json({ tips });
    } catch (error) {
      console.error("Error generating energy tips:", error);
      
      // Check for OpenAI API quota error
      const err = error as any;
      if (err.code === 'insufficient_quota' || 
          (err.message && typeof err.message === 'string' && err.message.includes('quota'))) {
        return res.status(200).json({ 
          tips: ["Unable to generate AI recommendations. OpenAI API quota exceeded."],
          error: "OpenAI API quota exceeded"
        });
      }
      
      res.status(200).json({ 
        tips: ["Unable to generate AI recommendations. Please try again later."],
        error: String(error)
      });
    }
  });

  // Process natural language commands
  apiRouter.post("/ai/command", async (req, res) => {
    try {
      const { command } = req.body;
      
      if (!command) {
        return res.status(400).json({ message: "Command text is required" });
      }
      
      // Load devices and rooms
      const devices = await storage.getAllDevices();
      const rooms = await storage.getAllRooms();
      
      // Process the command
      const result = await processNaturalLanguageCommand(command, devices, rooms);
      
      // If successful and there are actions, execute them
      if (result.success && result.actions && result.actions.length > 0) {
        // Execute each action
        for (const action of result.actions) {
          const device = await storage.getDevice(action.deviceId);
          
          if (!device) continue;
          
          // Apply action to device
          const updates: Partial<typeof device> = {};
          
          if (action.action === "turn_on") {
            updates.status = true;
          } else if (action.action === "turn_off") {
            updates.status = false;
          } else if (action.action === "set_brightness" && action.parameters?.brightness) {
            updates.brightness = Math.min(100, Math.max(0, action.parameters.brightness));
          } else if (action.action === "set_speed" && action.parameters?.speed) {
            updates.speed = Math.min(100, Math.max(0, action.parameters.speed));
          } else if (action.action === "set_color" && action.parameters?.color) {
            updates.color = action.parameters.color;
          }
          
          // Update device if there are changes
          if (Object.keys(updates).length > 0) {
            await storage.updateDevice(device.id, updates);
          }
        }
      }
      
      res.json(result);
    } catch (error) {
      console.error("Error processing command:", error);
      
      // Check for OpenAI API quota error
      const err = error as any;
      if (err.code === 'insufficient_quota' || 
          (err.message && typeof err.message === 'string' && err.message.includes('quota'))) {
        return res.status(200).json({ 
          success: false,
          message: "An error occurred while processing your command. Please try again.",
          error: "OpenAI API quota exceeded"
        });
      }
      
      res.status(200).json({ 
        success: false,
        message: "An error occurred while processing your command. Please try again.",
        error: String(error)
      });
    }
  });

  // Get automation rule suggestions
  apiRouter.get("/ai/rule-suggestions", async (_req, res) => {
    try {
      // Load required data
      const devices = await storage.getAllDevices();
      const rules = await storage.getAllRules();
      
      // Get energy usage for last 30 days
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - 30);
      const energyUsage = await storage.getEnergyUsage(startDate);
      
      // Generate automation suggestions
      const suggestions = await generateAutomationSuggestions(devices, energyUsage, rules);
      
      res.json({ suggestions });
    } catch (error) {
      console.error("Error generating rule suggestions:", error);
      
      // Check for OpenAI API quota error
      const err = error as any;
      if (err.code === 'insufficient_quota' || 
          (err.message && typeof err.message === 'string' && err.message.includes('quota'))) {
        return res.status(200).json({ 
          suggestions: [
            {
              name: "Default Morning Lighting Rule",
              description: "Turn on lights at 50% brightness in the morning",
              trigger: "Time-based (7:00 AM)",
              conditions: "Weekdays only",
              actions: "Turn on living room and kitchen lights at 50% brightness",
              benefit: "Creates a comfortable morning environment while using moderate energy"
            },
            {
              name: "Auto-Off When Away",
              description: "Turn off all devices when no one is home",
              trigger: "All users leave home",
              conditions: "No movement detected for 30 minutes",
              actions: "Turn off all lights and fans",
              benefit: "Prevents energy waste from devices left on accidentally"
            }
          ],
          error: "OpenAI API quota exceeded"
        });
      }
      
      res.status(200).json({ 
        suggestions: [
          {
            name: "Default Energy Saving Rule",
            description: "Turn off unused devices at night",
            trigger: "Time-based (11:00 PM)",
            conditions: "Every day",
            actions: "Turn off all lights and fans",
            benefit: "Reduces standby energy usage"
          }
        ],
        error: String(error)
      });
    }
  });
  
  // Gamification routes
  
  // Get user gamification profile
  apiRouter.get("/gamification/profile/:userId", async (req, res) => {
    try {
      const userId = Number(req.params.userId);
      const profile = await getUserGamificationProfile(userId);
      res.json(profile);
    } catch (error) {
      res.status(500).json({ message: String(error) });
    }
  });
  
  // Get all achievements
  apiRouter.get("/gamification/achievements", async (_req, res) => {
    try {
      const achievements = await getAllAchievements();
      res.json(achievements);
    } catch (error) {
      res.status(500).json({ message: String(error) });
    }
  });
  
  // Get user achievements
  apiRouter.get("/gamification/achievements/:userId", async (req, res) => {
    try {
      const userId = Number(req.params.userId);
      const achievements = await getUserAchievements(userId);
      res.json(achievements);
    } catch (error) {
      res.status(500).json({ message: String(error) });
    }
  });
  
  // Get active challenges
  apiRouter.get("/gamification/challenges", async (_req, res) => {
    try {
      const challenges = await getActiveChallenges();
      res.json(challenges);
    } catch (error) {
      res.status(500).json({ message: String(error) });
    }
  });
  
  // Get user challenges
  apiRouter.get("/gamification/challenges/:userId", async (req, res) => {
    try {
      const userId = Number(req.params.userId);
      const challenges = await getUserChallenges(userId);
      res.json(challenges);
    } catch (error) {
      res.status(500).json({ message: String(error) });
    }
  });
  
  // Update user points manually
  apiRouter.post("/gamification/points/:userId", async (req, res) => {
    try {
      const userId = Number(req.params.userId);
      const { points, reason } = req.body;
      
      if (points === undefined) {
        return res.status(400).json({ message: "Points value is required" });
      }
      
      const updatedUser = await updateUserPoints(userId, points);
      
      // Broadcast point update to WebSocket clients
      broadcastToWebSocketClients({
        type: 'pointsUpdate',
        userId,
        pointsAdded: points,
        reason: reason || 'Custom reward',
        newTotal: updatedUser.points || 0,
        newLevel: updatedUser.level || 1
      });
      
      res.json(updatedUser);
    } catch (error) {
      res.status(400).json({ message: String(error) });
    }
  });
  
  // Add middleware to process gamification for device updates
  apiRouter.use("/devices/:id", async (req: Request, res: Response, next: NextFunction) => {
    // Only intercept PUT requests
    if (req.method !== 'PUT') {
      return next();
    }
    
    // Save response.end to intercept later
    const originalEnd = res.end;
    // @ts-ignore - Overriding the end method type
    res.end = function(...args: any[]) {
      // Check if this was a successful response and status was being updated
      if (res.statusCode >= 200 && res.statusCode < 300 && 
          req.body && req.body.status !== undefined) {
        try {
          const deviceId = Number(req.params.id);
          // Process gamification asynchronously (don't await)
          storage.getDevice(deviceId)
            .then(device => {
              if (device) {
                // Process gamification for the first user (will be dynamic in production)
                processDeviceInteraction(1, deviceId, device.type)
                  .catch(err => console.error("Error processing device gamification:", err));
              }
            })
            .catch(err => console.error("Error getting device for gamification:", err));
        } catch (err) {
          console.error("Error in device gamification middleware:", err);
        }
      }
      
      // Call the original end method
      return originalEnd.apply(res, args);
    };
    
    next();
  });
  
  // Add middleware to process gamification for rule creation
  apiRouter.use("/rules", async (req: Request, res: Response, next: NextFunction) => {
    // Only intercept POST requests
    if (req.method !== 'POST') {
      return next();
    }
    
    // Save response.end to intercept later
    const originalEnd = res.end;
    // @ts-ignore - Overriding the end method type
    res.end = function(...args: any[]) {
      // Check if this was a successful response
      if (res.statusCode >= 200 && res.statusCode < 300) {
        try {
          // Process gamification asynchronously (don't await)
          processAutomationActivity(1, true)
            .catch(err => console.error("Error processing rule gamification:", err));
        } catch (err) {
          console.error("Error in rule gamification middleware:", err);
        }
      }
      
      // Call the original end method
      return originalEnd.apply(res, args);
    };
    
    next();
  });

  // Additional gamification endpoints are already defined above
  
  // Register API routes
  app.use("/api", apiRouter);

  // Create HTTP server
  const httpServer = createServer(app);

  // Create WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws) => {
    console.log('WebSocket client connected');
    wsClients.add(ws);

    // Send initial MQTT connection status
    ws.send(JSON.stringify({
      type: 'mqtt_status',
      connected: Boolean(mqttClient?.connected)
    }));

    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        // Handle device control messages
        if (data.type === 'device_control' && data.topic && data.message) {
          if (mqttClient && mqttClient.connected) {
            mqttClient.publish(data.topic, JSON.stringify(data.message));
          }
        }
      } catch (error) {
        console.error('Error handling WebSocket message:', error);
      }
    });

    ws.on('close', () => {
      console.log('WebSocket client disconnected');
      wsClients.delete(ws);
    });
  });

  return httpServer;
}
